#!/usr/bin/env node
/* Build: src/* -> dist/core.js, dist/ui.js, dist/index.html (single file), plus manifest/icons for hosting. */
const fs = require('fs');
const path = require('path');

const root = __dirname;
const dist = path.join(root, 'dist');
fs.mkdirSync(dist, { recursive: true });

const CORE_ORDER = ['util.js', 'plan.js', 'db.js', 'progression.js', 'stats.js', 'storage.js'];
const UI_ORDER = ['dom.js', 'brand.js', 'onboarding.js', 'today.js', 'train.js', 'profile.js', 'app.js'];

function concat(dir, order) {
  return order.map((f) => {
    const p = path.join(root, 'src', dir, f);
    if (!fs.existsSync(p)) return '';
    return '/* ===== ' + dir + '/' + f + ' ===== */\n' + fs.readFileSync(p, 'utf8') + '\n';
  }).join('\n');
}

const core = concat('core', CORE_ORDER);
fs.writeFileSync(path.join(dist, 'core.js'), core);

const ui = concat('ui', UI_ORDER);
fs.writeFileSync(path.join(dist, 'ui.js'), ui);

const css = fs.existsSync(path.join(root, 'src', 'styles.css')) ? fs.readFileSync(path.join(root, 'src', 'styles.css'), 'utf8') : '';
const tpl = fs.existsSync(path.join(root, 'src', 'index.html')) ? fs.readFileSync(path.join(root, 'src', 'index.html'), 'utf8') : '';

function dataUri(file, mime) {
  const p = path.join(root, 'assets', file);
  if (!fs.existsSync(p)) return '';
  return 'data:' + mime + ';base64,' + fs.readFileSync(p).toString('base64');
}

const icons = {
  favicon: dataUri('favicon.svg', 'image/svg+xml'),
  apple: dataUri('apple-touch-icon.png', 'image/png'),
  icon192: dataUri('icon-192.png', 'image/png'),
  icon512: dataUri('icon-512.png', 'image/png')
};

const manifest = {
  name: 'Coastal Strength', short_name: 'Coastal', start_url: './index.html', scope: './', display: 'standalone',
  background_color: '#0A1922', theme_color: '#0A1922',
  icons: [{ src: 'icon-192.png', sizes: '192x192', type: 'image/png' }, { src: 'icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any maskable' }]
};
fs.writeFileSync(path.join(dist, 'manifest.json'), JSON.stringify(manifest, null, 2));
const inlineManifest = Object.assign({}, manifest, { icons: [{ src: icons.icon192, sizes: '192x192', type: 'image/png' }, { src: icons.icon512, sizes: '512x512', type: 'image/png', purpose: 'any maskable' }] });

if (tpl) {
  const base = tpl.replace('/*__CSS__*/', () => css).replace('/*__CORE__*/', () => core).replace('/*__UI__*/', () => ui);
  // Hosted build: real files for icons + manifest (iOS home-screen icons need fetchable URLs), service worker registered.
  const hosted = base
    .replace(/__FAVICON__/g, 'favicon.svg')
    .replace(/__APPLE_ICON__/g, 'apple-touch-icon.png')
    .replace('__MANIFEST__', 'manifest.json');
  fs.writeFileSync(path.join(dist, 'index.html'), hosted);
  // Single-file preview: everything inline.
  const single = base
    .replace(/__FAVICON__/g, () => icons.favicon)
    .replace(/__APPLE_ICON__/g, () => icons.apple)
    .replace('__MANIFEST__', () => 'data:application/manifest+json,' + encodeURIComponent(JSON.stringify(inlineManifest)));
  fs.writeFileSync(path.join(dist, 'coastal-strength.html'), single);
  // Service worker: cache-first app shell, refreshed in the background. Version = hash of the built page.
  const version = 'cs-' + require('crypto').createHash('sha1').update(hosted).digest('hex').slice(0, 10);
  const sw = fs.readFileSync(path.join(root, 'src', 'sw.js'), 'utf8').replace('__VERSION__', version);
  fs.writeFileSync(path.join(dist, 'sw.js'), sw);
}

['favicon.svg', 'apple-touch-icon.png', 'icon-192.png', 'icon-512.png'].forEach((f) => {
  const p = path.join(root, 'assets', f);
  if (fs.existsSync(p)) fs.copyFileSync(p, path.join(dist, f));
});

console.log('built: core.js ' + core.length + ' bytes, ui.js ' + ui.length + ' bytes' + (tpl ? ', index.html ' + fs.statSync(path.join(dist, 'index.html')).size + ' bytes' : ''));

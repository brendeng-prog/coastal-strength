const vm = require('vm');
const fs = require('fs');
const path = require('path');

const CORE = fs.readFileSync(path.join(__dirname, '..', 'dist', 'core.js'), 'utf8');

/* Fresh CS namespace per call (fresh global state). */
function loadCore(extraWindow) {
  const ctx = Object.assign({ Intl, Date, Math, JSON, console, setTimeout, clearTimeout, Promise, Error, Object, Array, String, Number, isNaN }, extraWindow || {});
  ctx.window = ctx;
  vm.createContext(ctx);
  vm.runInContext(CORE, ctx);
  return ctx.CS;
}

const NOW = '2026-09-14T13:00:00.000Z'; // a Monday, 09:00 New York
const TZ = 'America/New_York';

function freshDb(CS, overrides) {
  return CS.db.createInitial(Object.assign({
    name: 'Brenden', weight: 172, weightUnit: 'lb', weightDate: '2026-09-14', heightIn: 73, units: 'lb', timezone: TZ
  }, overrides || {}), NOW);
}

/* Log a full session for a template: sets[i] = { load, reps, rir? } applied to every exercise,
   or perExercise[slotId] = [ {load,reps,rir}, ... ]. Marks completed. */
function logSession(CS, db, templateId, localDate, spec, opts) {
  opts = opts || {};
  const startIso = localDate + 'T13:00:00.000Z';
  const sid = CS.db.startSession(db, templateId, localDate, startIso);
  const s = db.sessions[sid];
  s.exercises.forEach((inst) => {
    const plan = (spec.perExercise && spec.perExercise[inst.slotId]) || spec.sets;
    if (!plan) return;
    plan.forEach((v, i) => {
      let set = inst.sets[i];
      if (!set) { const id = CS.db.addSet(db, sid, inst.instanceId, 'working'); set = inst.sets.find((x) => x.id === id); }
      if (v.load !== undefined) CS.db.setField(db, sid, inst.instanceId, set.id, 'load', v.load);
      if (v.reps !== undefined) CS.db.setField(db, sid, inst.instanceId, set.id, 'reps', v.reps);
      if (v.durationSec !== undefined) CS.db.setField(db, sid, inst.instanceId, set.id, 'durationSec', v.durationSec);
      if (v.rir !== undefined) CS.db.setField(db, sid, inst.instanceId, set.id, 'rir', v.rir);
      if (v.kind) CS.db.setKind(db, sid, inst.instanceId, set.id, v.kind);
      if (v.completed !== false) CS.db.toggleComplete(db, sid, inst.instanceId, set.id, localDate + 'T13:' + (10 + i) + ':00.000Z');
    });
  });
  if (!opts.leaveOpen) CS.db.finishSession(db, sid, localDate + 'T14:00:00.000Z');
  return sid;
}

module.exports = { loadCore, freshDb, logSession, NOW, TZ };

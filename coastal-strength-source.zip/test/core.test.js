const test = require('node:test');
const assert = require('node:assert/strict');
const { loadCore, freshDb, logSession, NOW, TZ } = require('./helpers');
/* Objects built inside the VM realm have different prototypes; compare by value. */
const norm = (x) => JSON.parse(JSON.stringify(x));
assert.deepEqual = (a, b, msg) => assert.deepStrictEqual(norm(a), norm(b), msg);

/* ---------- §6: seeded plan must match the spec exactly ---------- */
const SPEC_PLAN = {
  push: ['Incline dumbbell press 4x6-10', 'Flat machine press|Flat dumbbell press 3x8-12', 'Seated dumbbell shoulder press 3x6-10', 'Cable lateral raises 4x12-20', 'Rope triceps pushdowns 3x10-15', 'Overhead cable extensions 2x12-15'],
  pull: ['Pull-ups|Assisted pull-ups 4x6-10', 'Chest-supported rows 4x8-12', 'Neutral-grip lat pulldowns 3x8-12', 'Rear-delt flyes 4x12-20', 'Incline dumbbell curls 3x8-12', 'Hammer curls 2x10-15'],
  legs: ['Back squats|Hack squats 4x6-10', 'Romanian deadlifts 3x8-12', 'Bulgarian split squats 3x8-12 per side', 'Standing calf raises 4x10-15', 'Hanging leg raises 3x8-15', 'Cable crunches 3x10-15'],
  upper: ['Incline barbell press 4x6-10', 'Pull-ups|Lat pulldowns 4x8-12', 'Single-arm cable rows 3x10-12 per side', 'Dumbbell lateral raises 4x12-20', 'Cable curls 3x10-15', 'Triceps pushdowns 3x10-15'],
  conditioning: ['Ab-wheel rollouts 3x8-12', 'Reverse crunches 3x12-20', 'Side planks 3x30-45s per side']
};

function describeSlot(CS, slot) {
  const names = slot.options.map((id) => CS.plan.EXERCISE_MAP[id].name).join('|');
  const range = slot.timed ? slot.timed.secMin + '-' + slot.timed.secMax + 's' : slot.repMin + '-' + slot.repMax;
  return names + ' ' + slot.sets + 'x' + range + (slot.perSide ? ' per side' : '');
}

test('§6 seeded plan matches the spec exactly (names, order, set counts, rep ranges)', () => {
  const CS = loadCore();
  const T = CS.plan.DEFAULT_TEMPLATES;
  Object.keys(SPEC_PLAN).forEach((tid) => {
    assert.deepEqual(T[tid].slots.map((s) => describeSlot(CS, s)), SPEC_PLAN[tid], tid);
  });
  assert.equal(T.zone2.kind, 'cardio_optional');
  assert.equal(T.zone2.cardio.minutesMin, 30); assert.equal(T.zone2.cardio.minutesMax, 40);
  assert.deepEqual(T.conditioning.cardio.choices.map((c) => c.id), ['zone2', 'intervals']);
  assert.equal(T.conditioning.cardio.choices[1].rounds, 10);
  assert.equal(T.conditioning.cardio.choices[1].hardSec, 30);
  assert.equal(T.conditioning.cardio.choices[1].easySec, 90);
  assert.equal(T.conditioning.circuit.rounds, 3);
  assert.deepEqual(CS.plan.DEFAULT_SCHEDULE, { push: 'mon', pull: 'tue', legs: 'wed', zone2: 'thu', upper: 'fri', conditioning: 'sat' });
});

test('§17.1 onboarding produces the exact default plan and honors OR-slot picks', () => {
  const CS = loadCore();
  const db = freshDb(CS, { picks: { pull_1: 'assisted_pullup', legs_1: 'hack_squat' } });
  const plan = CS.db.activePlan(db);
  assert.deepEqual(plan.templates, CS.plan.DEFAULT_TEMPLATES);
  assert.equal(plan.version, 1);
  assert.equal(db.profile.picks.pull_1, 'assisted_pullup');
  assert.equal(db.profile.picks.push_2, 'flat_mach_press'); // default first option
  const sid = CS.db.createSession(db, 'pull', '2026-09-15', NOW);
  const s = db.sessions[sid];
  assert.equal(s.exercises[0].exerciseId, 'assisted_pullup');
  assert.deepEqual(s.exercises.map((e) => e.prescription.sets), [4, 4, 3, 4, 3, 2]);
  assert.equal(s.exercises[0].sets.length, 4);
  assert.equal(CS.db.latestMeasurement(db, 'weight').value, 172);
  assert.equal(db.sessionOrder.length, 1);
  // Brand-new account: no invented workouts or progress
  const db2 = freshDb(CS);
  assert.equal(db2.sessionOrder.length, 0);
  assert.equal(CS.stats.weekRing(db2, '2026-09-14').completed, 0);
});

/* ---------- prefill, completion, undo ---------- */
test('§17.4 prefilled values are never counted as completed', () => {
  const CS = loadCore();
  const db = freshDb(CS);
  logSession(CS, db, 'push', '2026-09-14', { sets: [{ load: 50, reps: 8 }, { load: 50, reps: 8 }, { load: 50, reps: 7 }, { load: 50, reps: 7 }] });
  const sid = CS.db.startSession(db, 'push', '2026-09-21', '2026-09-21T13:00:00.000Z');
  const s = db.sessions[sid];
  const inst = s.exercises[0];
  assert.equal(inst.sets[0].load, 50);
  assert.equal(inst.sets[0].reps, 8);
  assert.equal(inst.sets[0].prefilled, true);
  assert.equal(inst.sets[0].completed, false);
  assert.deepEqual(CS.db.counts(s), { workingDone: 0, workingPrescribed: 19, exercisesDone: 0, exercisesTotal: 6, warmupsDone: 0 });
  // Finishing with prefilled-only sets records nothing as done and suggests nothing
  CS.db.finishSession(db, sid, '2026-09-21T14:00:00.000Z');
  assert.equal(CS.db.counts(s).workingDone, 0);
  const sg = db.suggestions[sid + ':' + inst.instanceId];
  assert.equal(sg.result.status, 'none');
});

test('§17.5 undoing a completed set corrects all totals', () => {
  const CS = loadCore();
  const db = freshDb(CS);
  const sid = CS.db.startSession(db, 'push', '2026-09-14', NOW);
  const inst = db.sessions[sid].exercises[0];
  const ids = inst.sets.map((x) => x.id);
  ids.forEach((id, i) => { CS.db.setField(db, sid, inst.instanceId, id, 'load', 50); CS.db.setField(db, sid, inst.instanceId, id, 'reps', 10); CS.db.toggleComplete(db, sid, inst.instanceId, id, NOW); });
  assert.equal(CS.db.counts(db.sessions[sid]).workingDone, 4);
  assert.equal(CS.db.counts(db.sessions[sid]).exercisesDone, 1);
  CS.db.toggleComplete(db, sid, inst.instanceId, ids[3], NOW); // undo
  const c = CS.db.counts(db.sessions[sid]);
  assert.equal(c.workingDone, 3);
  assert.equal(c.exercisesDone, 0);
  assert.equal(inst.sets[3].completed, false);
  assert.equal(inst.sets[3].completedAt, null);
});

test('§17.6 finishing a session updates history and the week ring', () => {
  const CS = loadCore();
  const db = freshDb(CS);
  assert.equal(CS.stats.weekRing(db, '2026-09-14').completed, 0);
  assert.equal(CS.stats.weekRing(db, '2026-09-14').scheduled, 4);
  logSession(CS, db, 'push', '2026-09-14', { sets: [{ load: 50, reps: 8 }] });
  const ring = CS.stats.weekRing(db, '2026-09-16');
  assert.equal(ring.completed, 1);
  assert.equal(ring.scheduled, 4);
  assert.equal(CS.progression.history(db, 'inc_db_press').length, 1);
  assert.equal(CS.progression.history(db, 'inc_db_press')[0].status, 'completed');
});

/* ---------- progression ---------- */
function evalFirst(CS, db, sid) {
  const s = db.sessions[sid];
  return db.suggestions[sid + ':' + s.exercises[0].instanceId].result;
}

test('§17.7 a qualifying 4×10 session produces the correct increase suggestion', () => {
  const CS = loadCore();
  const db = freshDb(CS);
  const sid = logSession(CS, db, 'push', '2026-09-14', { sets: [{ load: 50, reps: 10 }, { load: 50, reps: 10 }, { load: 50, reps: 10 }, { load: 50, reps: 10 }] });
  const r = evalFirst(CS, db, sid);
  assert.equal(r.status, 'increase');
  assert.equal(r.currentLoad, 50);
  assert.equal(r.suggestedLoad, 55); // dumbbell increment 5 lb, per dumbbell
  assert.equal(r.unit, 'lb');
  assert.ok(r.reasons.some((x) => /4 of 4 sets reached 10 reps/.test(x)));
  assert.equal(r.rirNote, 'RIR was not logged, so this used load and reps only.');
  assert.ok(r.reasons.indexOf(r.rirNote) >= 0);
});

test('§17.8 a missing set, and a 10/10/9/8 session, produce NO increase', () => {
  const CS = loadCore();
  const db = freshDb(CS);
  const a = logSession(CS, db, 'push', '2026-09-14', { sets: [{ load: 50, reps: 10 }, { load: 50, reps: 10 }, { load: 50, reps: 9 }, { load: 50, reps: 8 }] });
  const ra = evalFirst(CS, db, a);
  assert.equal(ra.status, 'none');
  assert.equal(ra.suggestedLoad, null);
  assert.ok(ra.reasons.some((x) => /2 of 4 sets reached 10 reps/.test(x)));
  const b = logSession(CS, db, 'push', '2026-09-21', { sets: [{ load: 50, reps: 10 }, { load: 50, reps: 10 }, { load: 50, reps: 10 }] });
  const rb = evalFirst(CS, db, b);
  assert.equal(rb.status, 'none');
  assert.ok(rb.reasons.some((x) => /3 of 4 prescribed working sets completed/.test(x)));
});

test('extra sets do not substitute for missing prescribed sets; warm-ups are excluded', () => {
  const CS = loadCore();
  const db = freshDb(CS);
  // Warm-up at 10 reps must not count; prescribed sets 10/10/9 + extra 10 must not increase
  const sid = logSession(CS, db, 'push', '2026-09-14', {
    perExercise: { push_1: [{ load: 50, reps: 10 }, { load: 50, reps: 10 }, { load: 50, reps: 9 }, { load: 50, reps: 10 }, { load: 50, reps: 10 }] }
  });
  const s = db.sessions[sid];
  const inst = s.exercises[0];
  // Turn set 1 into a warm-up after the fact -> prescribed working sets become 10/9/10/10 -> still no increase
  CS.db.setKind(db, sid, inst.instanceId, inst.sets[0].id, 'warmup');
  s.status = 'in_progress'; CS.db.finishSession(db, sid, '2026-09-14T15:00:00.000Z');
  const r = evalFirst(CS, db, sid);
  assert.equal(r.status, 'none');
  assert.ok(r.reasons.some((x) => /Warm-up sets excluded. 4 of 4/.test(x)));
  assert.ok(r.reasons.some((x) => /3 of 4 sets reached 10 reps/.test(x)));
  // Make it 5 working sets where the first four are 10/10/10/9 and the fifth is 10: extra set can't rescue
  const db2 = freshDb(CS);
  const sid2 = logSession(CS, db2, 'push', '2026-09-14', { perExercise: { push_1: [{ load: 50, reps: 10 }, { load: 50, reps: 10 }, { load: 50, reps: 10 }, { load: 50, reps: 9 }, { load: 50, reps: 10 }] } });
  const r2 = evalFirst(CS, db2, sid2);
  assert.equal(r2.status, 'none');
  assert.ok(r2.reasons.some((x) => /1 extra set/.test(x)));
});

test('mixed-load sessions and unfinished sessions never trigger an increase', () => {
  const CS = loadCore();
  const db = freshDb(CS);
  const sid = logSession(CS, db, 'push', '2026-09-14', { sets: [{ load: 50, reps: 10 }, { load: 55, reps: 10 }, { load: 50, reps: 10 }, { load: 50, reps: 10 }] });
  const r = evalFirst(CS, db, sid);
  assert.equal(r.status, 'none');
  assert.ok(r.reasons.some((x) => /different loads/.test(x)));
  const db2 = freshDb(CS);
  const open = logSession(CS, db2, 'push', '2026-09-14', { sets: [{ load: 50, reps: 10 }, { load: 50, reps: 10 }, { load: 50, reps: 10 }, { load: 50, reps: 10 }] }, { leaveOpen: true });
  const s = db2.sessions[open];
  const r2 = CS.progression.evaluate({ exercise: CS.db.exercise(db2, 'inc_db_press'), instance: s.exercises[0], session: s, db: db2 });
  assert.equal(r2.status, 'not_evaluated');
  assert.equal(Object.keys(db2.suggestions).length, 0);
});

test('§17.9 assisted pull-up progression reduces assistance; the three vertical-pull series stay separate', () => {
  const CS = loadCore();
  const db = freshDb(CS, { picks: { pull_1: 'assisted_pullup' } });
  const sid = logSession(CS, db, 'pull', '2026-09-15', { perExercise: { pull_1: [{ load: 40, reps: 10 }, { load: 40, reps: 10 }, { load: 40, reps: 10 }, { load: 40, reps: 10 }] } });
  const r = evalFirst(CS, db, sid);
  assert.equal(r.status, 'assist_decrease');
  assert.equal(r.suggestedLoad, 35);
  assert.ok(r.reasons.some((x) => /Less assistance is progress/.test(x)));
  assert.equal(CS.progression.history(db, 'pullup').length, 0);
  assert.equal(CS.progression.history(db, 'lat_pulldown').length, 0);
  assert.equal(CS.progression.history(db, 'assisted_pullup').length, 1);
  // Accepting the suggestion prefills the next assisted session with 35, and pull-ups are unaffected
  CS.db.decideSuggestion(db, sid + ':' + db.sessions[sid].exercises[0].instanceId, 'accepted');
  const next = CS.db.startSession(db, 'pull', '2026-09-22', '2026-09-22T13:00:00.000Z');
  assert.equal(db.sessions[next].exercises[0].sets[0].load, 35);
  assert.equal(db.sessions[next].exercises[0].sets[0].completed, false);
});

test('suggestion decisions: accepted prefills the new load, dismissed keeps the old, overridden uses the override', () => {
  const CS = loadCore();
  const db = freshDb(CS);
  const four10 = { sets: [{ load: 50, reps: 10 }, { load: 50, reps: 10 }, { load: 50, reps: 10 }, { load: 50, reps: 10 }] };
  const a = logSession(CS, db, 'push', '2026-09-14', four10);
  const key = a + ':' + db.sessions[a].exercises[0].instanceId;
  CS.db.decideSuggestion(db, key, 'dismissed');
  const b = CS.db.startSession(db, 'push', '2026-09-21', '2026-09-21T13:00:00.000Z');
  assert.equal(db.sessions[b].exercises[0].sets[0].load, 50);
  CS.db.finishSession(db, b, '2026-09-21T14:00:00.000Z');
  const c = logSession(CS, db, 'push', '2026-09-28', four10);
  const keyC = c + ':' + db.sessions[c].exercises[0].instanceId;
  CS.db.decideSuggestion(db, keyC, 'overridden', 52.5);
  const d = CS.db.startSession(db, 'push', '2026-10-05', '2026-10-05T13:00:00.000Z');
  assert.equal(db.sessions[d].exercises[0].sets[0].load, 52.5);
  assert.equal(db.suggestions[keyC].consumedBy, d);
});

test('RIR of 0 flags that holding may be appropriate; kg increments are respected', () => {
  const CS = loadCore();
  const db = freshDb(CS, { units: 'kg', weight: 78, weightUnit: 'kg' });
  const sid = logSession(CS, db, 'upper', '2026-09-18', { perExercise: { upper_1: [{ load: 60, reps: 10, rir: 1 }, { load: 60, reps: 10, rir: 1 }, { load: 60, reps: 10, rir: 0 }, { load: 60, reps: 10, rir: 0 }] } });
  const r = evalFirst(CS, db, sid);
  assert.equal(r.status, 'increase');
  assert.equal(r.unit, 'kg');
  assert.equal(r.suggestedLoad, 62.5);
  assert.equal(r.rirFlag, true);
  assert.equal(r.rirNote, null);
  assert.ok(r.reasons.some((x) => /0 RIR/.test(x)));
});

test('bodyweight and timed progression: reps/control first, then harder variation; holds progress to the upper bound', () => {
  const CS = loadCore();
  const db = freshDb(CS);
  const sid = logSession(CS, db, 'pull', '2026-09-15', { perExercise: { pull_1: [{ reps: 10 }, { reps: 10 }, { reps: 10 }, { reps: 10 }] } });
  const r = evalFirst(CS, db, sid);
  assert.equal(r.status, 'bodyweight_top');
  assert.equal(r.suggestedLoad, null);
  assert.ok(r.reasons.some((x) => /weighted pull-ups \(a separate history\)/.test(x)));
  const db2 = freshDb(CS);
  const c = logSession(CS, db2, 'conditioning', '2026-09-19', { perExercise: { cond_3: [{ durationSec: 30 }, { durationSec: 40 }, { durationSec: 45 }] } });
  const inst = db2.sessions[c].exercises[2];
  const rt = db2.suggestions[c + ':' + inst.instanceId].result;
  assert.equal(rt.status, 'none');
  assert.ok(rt.reasons.some((x) => /1 of 3 holds reached 45 s/.test(x)));
  // No 1RM-style or load suggestion for a timed hold
  assert.equal(rt.suggestedLoad, null);
});

test('§17.10 substitutions keep separate exercise histories', () => {
  const CS = loadCore();
  const db = freshDb(CS);
  logSession(CS, db, 'push', '2026-09-14', { perExercise: { push_2: [{ load: 120, reps: 12 }, { load: 120, reps: 12 }, { load: 120, reps: 12 }] } });
  const sid = CS.db.startSession(db, 'push', '2026-09-21', '2026-09-21T13:00:00.000Z');
  const inst = db.sessions[sid].exercises[1];
  assert.equal(inst.exerciseId, 'flat_mach_press');
  assert.equal(inst.sets[0].load, 120); // prefilled from machine press history
  const ok = CS.db.substituteExercise(db, sid, inst.instanceId, 'flat_db_press');
  assert.equal(ok, true);
  assert.equal(inst.exerciseId, 'flat_db_press');
  assert.equal(inst.substitutedFrom, 'flat_mach_press');
  assert.equal(inst.sets[0].load, null); // dumbbell press has no history -> nothing prefilled
  assert.equal(inst.sets[0].prefilled, false);
  inst.sets.forEach((x) => { CS.db.setField(db, sid, inst.instanceId, x.id, 'load', 60); CS.db.setField(db, sid, inst.instanceId, x.id, 'reps', 10); CS.db.toggleComplete(db, sid, inst.instanceId, x.id, NOW); });
  CS.db.finishSession(db, sid, '2026-09-21T14:00:00.000Z');
  assert.equal(CS.progression.history(db, 'flat_mach_press').length, 1);
  assert.equal(CS.progression.history(db, 'flat_db_press').length, 1);
  assert.equal(CS.progression.history(db, 'flat_mach_press')[0].sets[0].load, 120);
  assert.equal(CS.progression.history(db, 'flat_db_press')[0].sets[0].load, 60);
  // Substituting after logged work is refused
  const sid2 = CS.db.startSession(db, 'push', '2026-09-28', '2026-09-28T13:00:00.000Z');
  const i2 = db.sessions[sid2].exercises[1];
  CS.db.toggleComplete(db, sid2, i2.instanceId, i2.sets[0].id, NOW);
  assert.equal(CS.db.substituteExercise(db, sid2, i2.instanceId, 'flat_mach_press'), false);
});

test('§17.14 rest days and cardio days do not reduce lifting adherence', () => {
  const CS = loadCore();
  const db = freshDb(CS);
  ['push', 'pull', 'legs', 'upper'].forEach((t, i) => logSession(CS, db, t, '2026-09-' + (14 + [0, 1, 2, 4][i]), { sets: [{ load: 50, reps: 8 }] }));
  const ring = CS.stats.weekRing(db, '2026-09-20'); // Sunday of that week
  assert.equal(ring.completed, 4);
  assert.equal(ring.scheduled, 4);
  assert.equal(ring.days.filter((d) => d.kind === 'lift').length, 4);
  assert.equal(ring.days.find((d) => d.key === 'thu').kind, 'cardio_optional');
  assert.equal(ring.days.find((d) => d.key === 'sun').kind, 'rest');
  // Doing Push on Tuesday instead of Monday still counts once
  const db2 = freshDb(CS);
  logSession(CS, db2, 'push', '2026-09-15', { sets: [{ load: 50, reps: 8 }] });
  logSession(CS, db2, 'push', '2026-09-16', { sets: [{ load: 50, reps: 8 }] });
  assert.equal(CS.stats.weekRing(db2, '2026-09-16').completed, 1);
});

test('unilateral linked vs separate sides: pairs collapse to one logical set and both sides must qualify', () => {
  const CS = loadCore();
  const db = freshDb(CS);
  const sid = CS.db.startSession(db, 'legs', '2026-09-16', NOW);
  const inst = db.sessions[sid].exercises[2]; // Bulgarian split squats, 3×8–12 per leg
  assert.equal(inst.sets.length, 3);
  CS.db.setSidesSeparate(db, sid, inst.instanceId, true);
  assert.equal(inst.sets.length, 6);
  const pairs = {};
  inst.sets.forEach((x) => { pairs[x.pairId] = (pairs[x.pairId] || 0) + 1; });
  assert.deepEqual(Object.values(pairs), [2, 2, 2]);
  inst.sets.forEach((x, i) => { CS.db.setField(db, sid, inst.instanceId, x.id, 'load', 30); CS.db.setField(db, sid, inst.instanceId, x.id, 'reps', x.side === 'R' && i === 5 ? 11 : 12); CS.db.toggleComplete(db, sid, inst.instanceId, x.id, NOW); });
  assert.equal(CS.db.counts(db.sessions[sid]).workingDone, 3);
  CS.db.finishSession(db, sid, '2026-09-16T14:00:00.000Z');
  const r = db.suggestions[sid + ':' + inst.instanceId].result;
  assert.equal(r.status, 'none'); // third set right leg hit 11 -> logical reps 11 -> no increase
  assert.ok(r.reasons.some((x) => /12\/12\/11/.test(x)));
});

/* ---------- timers ---------- */
test('§17.15 session elapsed time and rest timer are timestamp-based and survive backgrounding', () => {
  const CS = loadCore();
  const db = freshDb(CS);
  const t0 = Date.parse('2026-09-14T13:00:00.000Z');
  const sid = CS.db.startSession(db, 'push', '2026-09-14', new Date(t0).toISOString());
  const s = db.sessions[sid];
  assert.equal(CS.db.activeMs(s, t0 + 10 * 60000), 10 * 60000);
  CS.db.pauseSession(db, sid, new Date(t0 + 10 * 60000).toISOString());
  assert.equal(CS.db.activeMs(s, t0 + 25 * 60000), 10 * 60000); // paused time excluded
  CS.db.resumeSession(db, sid, new Date(t0 + 25 * 60000).toISOString());
  assert.equal(CS.db.activeMs(s, t0 + 30 * 60000), 15 * 60000);
  // Rest timer: 150 s started, app "backgrounded" for 200 s -> done, no drift
  CS.db.startRest(db, 150, t0, sid);
  assert.equal(CS.db.restState(db, t0 + 100000).remainingSec, 50);
  assert.equal(CS.db.restState(db, t0 + 200000).done, true);
  CS.db.startRest(db, 90, t0, sid);
  CS.db.pauseRest(db, t0 + 30000);
  assert.equal(CS.db.restState(db, t0 + 999999).remainingSec, 60);
  CS.db.resumeRest(db, t0 + 999999);
  assert.equal(CS.db.restState(db, t0 + 999999 + 30000).remainingSec, 30);
  CS.db.adjustRest(db, 30, t0 + 999999 + 30000);
  assert.equal(CS.db.restState(db, t0 + 999999 + 30000).remainingSec, 60);
  // Round-trip through JSON (what persistence does) keeps the timer intact
  const copy = JSON.parse(JSON.stringify(db));
  assert.equal(CS.db.restState(copy, t0 + 999999 + 30000).remainingSec, 60);
});

/* ---------- local dates & units ---------- */
test('timezone-correct local calendar dates', () => {
  const CS = loadCore();
  const U = CS.util;
  assert.equal(U.localDate('2026-09-14T03:30:00.000Z', 'America/New_York'), '2026-09-13'); // 11:30 pm the day before in NY
  assert.equal(U.localDate('2026-09-14T03:30:00.000Z', 'UTC'), '2026-09-14');
  assert.equal(U.localDate('2026-09-14T03:30:00.000Z', 'Asia/Tokyo'), '2026-09-14');
  assert.equal(U.weekday('2026-09-14'), 'mon');
  assert.equal(U.weekday('2026-09-20'), 'sun');
  assert.equal(U.weekStart('2026-09-20'), '2026-09-14');
  assert.equal(U.addDays('2026-09-30', 1), '2026-10-01');
  assert.equal(U.diffDays('2026-09-14', '2026-09-21'), 7);
});

test('unit handling: switching units converts prefill; invalid and negative input is rejected', () => {
  const CS = loadCore();
  const db = freshDb(CS);
  logSession(CS, db, 'push', '2026-09-14', { sets: [{ load: 50, reps: 8 }] });
  db.profile.units = 'kg';
  const sid = CS.db.startSession(db, 'push', '2026-09-21', '2026-09-21T13:00:00.000Z');
  const set = db.sessions[sid].exercises[0].sets[0];
  assert.equal(set.unit, 'kg');
  assert.equal(set.load, 22.5); // 50 lb = 22.68 kg, rounded to 0.5
  const U = CS.util;
  assert.equal(U.parseNum('-5').error, "Can't be negative.");
  assert.equal(U.parseNum('abc').error, 'Enter a number.');
  assert.equal(U.parseNum('').value, null);
  assert.equal(U.parseNum('12,5').value, 12.5);
  assert.equal(U.parseNum('7.5', { integer: true }).error, 'Whole numbers only.');
});

test('§17.13 weight averages: no 7-day average below 3 observations; missing days never become zeros', () => {
  const CS = loadCore();
  const db = freshDb(CS, { weightDate: '2026-09-10' });
  let w = CS.stats.weightSummary(db, '2026-09-14');
  assert.equal(w.avg7, null);
  assert.equal(w.avg7Count, 1);
  CS.db.addMeasurement(db, { type: 'weight', value: 173, unit: 'lb', localDate: '2026-09-12' }, NOW);
  w = CS.stats.weightSummary(db, '2026-09-14');
  assert.equal(w.avg7, null); // 2 observations
  CS.db.addMeasurement(db, { type: 'weight', value: 171, unit: 'lb', localDate: '2026-09-14' }, NOW);
  w = CS.stats.weightSummary(db, '2026-09-14');
  assert.equal(w.avg7, 172); // mean of 172, 173, 171 — the 4 missing days contribute nothing
  assert.equal(w.latest.value, 171);
  assert.equal(w.latest.localDate, '2026-09-14');
});

/* ---------- store: serialized, idempotent saves ---------- */
test('store: debounced, serialized writes; a retried save cannot duplicate sessions', async () => {
  const CS = loadCore();
  const writes = [];
  let failNext = 1;
  const backend = {
    mode: 'fake', label: 'fake', async probe() { return true; }, async load() { return writes.length ? writes[writes.length - 1] : null; },
    async save(json) { if (failNext > 0) { failNext--; throw new Error('boom'); } writes.push(json); }, async clear() { writes.length = 0; }
  };
  const store = CS.storage.createStore(backend, { debounceMs: 5 });
  store.set(freshDb(CS));
  for (let i = 0; i < 5; i++) store.commit((db) => CS.db.startSession(db, 'push', '2026-09-14', NOW));
  await new Promise((r) => setTimeout(r, 2300)); // covers the 2 s retry after the injected failure
  assert.ok(writes.length >= 1);
  const last = JSON.parse(writes[writes.length - 1]);
  assert.equal(last.sessionOrder.length, 1); // five starts of the same session on the same day -> one session
  assert.equal(store.status.state, 'saved');
  // Reload from what was written
  const store2 = CS.storage.createStore(backend, { debounceMs: 5 });
  const db2 = await store2.load();
  assert.equal(db2.sessionOrder.length, 1);
  assert.equal(db2.sessions[db2.sessionOrder[0]].status, 'in_progress');
});

test('storage detection falls back in order and never claims a backend that failed its probe', async () => {
  const CS = loadCore({ storage: { async get() { throw new Error('x'); }, async set() { return null; }, async delete() { } } });
  const b = await CS.storage.detect();
  assert.equal(b.mode, 'memory'); // preview set() returned null -> probe fails; no IndexedDB/localStorage in this context
  const CS2 = loadCore({ storage: { store: {}, async get(k) { if (!(k in this.store)) throw new Error('missing'); return { key: k, value: this.store[k] }; }, async set(k, v) { this.store[k] = v; return { key: k, value: v }; }, async delete(k) { delete this.store[k]; return { key: k, deleted: true }; } } });
  const b2 = await CS2.storage.detect();
  assert.equal(b2.mode, 'preview');
  assert.equal(await b2.load(), null);
  await b2.save('{"a":1}');
  assert.equal(await b2.load(), '{"a":1}');
});

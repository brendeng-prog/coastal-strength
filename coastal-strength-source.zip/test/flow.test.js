/* End-to-end flow in jsdom (not a real browser: no layout, no real timers of Safari).
   Uses a shared fake window.storage so a second JSDOM instance behaves like a reload. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');

const HTML = fs.readFileSync(path.join(__dirname, '..', 'dist', 'index.html'), 'utf8');

function fakePreviewStorage() {
  const store = {};
  return {
    _store: store,
    async get(k, shared) { if (!(k in store)) throw new Error('Key not found: ' + k); return { key: k, value: store[k], shared: !!shared }; },
    async set(k, v, shared) { store[k] = v; return { key: k, value: v, shared: !!shared }; },
    async delete(k, shared) { const had = k in store; delete store[k]; return { key: k, deleted: had, shared: !!shared }; },
    async list(prefix, shared) { return { keys: Object.keys(store).filter((x) => !prefix || x.startsWith(prefix)), prefix, shared: !!shared }; }
  };
}

const OPEN = [];
test.afterEach(() => { while (OPEN.length) { try { OPEN.pop().window.close(); } catch (e) { /* ignore */ } } });

function open(storage) {
  const dom = new JSDOM(HTML, {
    runScripts: 'dangerously', pretendToBeVisual: true, url: 'https://example.test/app/',
    beforeParse(window) {
      if (storage) window.storage = storage;
      window.scrollTo = () => {};
      window.HTMLElement.prototype.scrollIntoView = function () {};
      window.requestAnimationFrame = (f) => setTimeout(f, 0);
    }
  });
  dom.window.console.error = (...a) => { throw new Error('console.error: ' + a.join(' ')); };
  OPEN.push(dom);
  return dom;
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function settle(ms) { await sleep(ms || 60); }

function $(dom, sel) { return dom.window.document.querySelector(sel); }
function $$(dom, sel) { return Array.from(dom.window.document.querySelectorAll(sel)); }
/* Rendered text only — body.textContent would include the inline script source. */
function text(dom) {
  const d = dom.window.document;
  return Array.from(d.querySelectorAll('#app, #timerbar, #tabs, .sheet-back, .toast')).map((n) => n.textContent).join(' ').replace(/\s+/g, ' ');
}
function buttonWithText(dom, t, within) {
  const scope = within || dom.window.document;
  return Array.from(scope.querySelectorAll('button')).find((b) => b.textContent.trim() === t);
}
async function click(dom, btn) { assert.ok(btn, 'button to click exists'); btn.click(); await settle(); }
function type(dom, input, value) {
  input.value = value;
  input.dispatchEvent(new dom.window.Event('input', { bubbles: true }));
}
async function waitFor(fn, label, tries) {
  for (let i = 0; i < (tries || 60); i++) { if (fn()) return; await sleep(25); }
  throw new Error('timeout waiting for ' + label);
}

test('flow: onboarding → start → log → reload → resume → undo → finish → suggestion → next session prefill', async () => {
  const storage = fakePreviewStorage();
  let dom = open(storage);
  await waitFor(() => /Step 1 of 5/.test(text(dom)), 'onboarding');
  const CS = dom.window.CS;
  assert.equal(CS.app.store.backend.mode, 'preview');

  // Step 1: weight must be confirmed (button carries the number) — confirm 172 lb
  await click(dom, buttonWithText(dom, 'Confirm 172 lb'));
  assert.match(text(dom), /Step 2 of 5/);
  await click(dom, buttonWithText(dom, 'Continue'));
  assert.match(text(dom), /Step 3 of 5/);
  await click(dom, buttonWithText(dom, 'Skip'));
  assert.match(text(dom), /Step 4 of 5/);
  await click(dom, buttonWithText(dom, 'Continue'));
  assert.match(text(dom), /Step 5 of 5/);
  assert.match(text(dom), /skeletal frame and proportions are not trainable/i);
  await click(dom, buttonWithText(dom, 'Go to Today'));

  // Today: real data only. Weight from onboarding, ring 0/4, no invented sessions.
  assert.match(text(dom), /172 lb/);
  assert.match(text(dom), /0 of 4 sessions this week/);
  assert.match(text(dom), /Not enough weight history/);
  let db = CS.app.store.db;
  assert.equal(db.sessionOrder.length, 0);
  assert.equal(CS.db.latestMeasurement(db, 'weight').value, 172);
  assert.equal($$(dom, '.screen .card').length <= 5, true, 'Today shows at most 5 cards');

  // Go to Train and start Push (today if Monday, otherwise "Start today")
  await click(dom, $$(dom, '#tabs .tab').find((b) => b.getAttribute('aria-label') === 'Train'));
  const pushRow = $$(dom, '.weekrow').find((r) => /Push/.test(r.textContent));
  await click(dom, buttonWithText(dom, 'Start', pushRow) || buttonWithText(dom, 'Start today', pushRow));
  await waitFor(() => $$(dom, '.excard').length === 6, 'logger with 6 exercises');
  assert.match(text(dom), /0 of 19 working sets/);
  db = CS.app.store.db;
  const sid = db.sessionOrder[0];
  assert.equal(db.sessions[sid].status, 'in_progress');
  assert.equal(db.sessions[sid].exercises.map((e) => e.prescription.sets).join(','), '4,3,3,4,3,2');

  // No history -> nothing prefilled; typing does not complete anything
  const card1 = $$(dom, '.excard')[0];
  assert.match(card1.textContent, /No history yet/);
  const rows = card1.querySelectorAll('.setrow');
  assert.equal(rows.length, 4);
  const loadInput = (r) => r.querySelector('input[aria-label^="Load"]');
  const repsInput = (r) => r.querySelector('input[aria-label^="Reps"]');
  type(dom, loadInput(rows[0]), '50'); type(dom, repsInput(rows[0]), '8');
  type(dom, loadInput(rows[1]), '50'); type(dom, repsInput(rows[1]), '8');
  type(dom, loadInput(rows[2]), '-5'); // rejected
  await settle();
  assert.equal(CS.db.counts(CS.app.store.db.sessions[sid]).workingDone, 0);
  assert.equal(CS.app.store.db.sessions[sid].exercises[0].sets[2].load, null, 'negative input is rejected');
  assert.equal(loadInput(rows[2]).classList.contains('invalid'), true);

  // Complete two sets -> counts update, rest timer starts (150 s compound)
  await click(dom, rows[0].querySelector('.setcheck'));
  await click(dom, $$(dom, '.excard')[0].querySelectorAll('.setrow')[1].querySelector('.setcheck'));
  assert.match(text(dom), /2 of 19 working sets/);
  assert.equal($(dom, '#timerbar').hidden, false);
  assert.match($(dom, '#restclock').textContent, /^2:(2|3)\d$/);

  // Wait for autosave, then "reload"
  await waitFor(() => CS.app.store.status.state === 'saved', 'saved');
  assert.match($(dom, '.status').textContent, /Saved/);
  dom.window.close();
  dom = open(storage);
  await waitFor(() => /Resume workout/.test(text(dom)), 'Today after reload shows Resume');
  const CS2 = dom.window.CS;
  assert.equal(CS2.app.store.backend.mode, 'preview');
  assert.match(text(dom), /2 of 19 working sets logged/);
  await click(dom, buttonWithText(dom, 'Resume workout'));
  await waitFor(() => $$(dom, '.excard').length === 6, 'logger after reload');
  const s2 = CS2.app.store.db.sessions[sid];
  assert.equal(s2.status, 'in_progress');
  assert.equal(s2.exercises[0].sets[0].load, 50);
  assert.equal(s2.exercises[0].sets[0].reps, 8);
  assert.equal(s2.exercises[0].sets[0].completed, true);
  assert.equal(s2.exercises[0].sets[1].completed, true);
  assert.equal(s2.exercises[0].sets[2].completed, false);
  assert.equal($$(dom, '.setrow.done').length, 2);
  assert.ok(CS2.db.activeMs(s2, Date.now()) > 0, 'elapsed time survives reload (from timestamps)');
  assert.equal($(dom, '#timerbar').hidden, false, 'rest timer survives reload');
  assert.match($(dom, '#restclock').textContent, /^2:\d\d$/);

  // Undo set 2 -> totals correct
  await click(dom, $$(dom, '.excard')[0].querySelectorAll('.setrow')[1].querySelector('.setcheck'));
  assert.match(text(dom), /1 of 19 working sets/);
  assert.equal(CS2.db.counts(CS2.app.store.db.sessions[sid]).workingDone, 1);

  // Log all four incline DB press sets at 50 × 10, then finish
  const c1 = $$(dom, '.excard')[0];
  const rs = c1.querySelectorAll('.setrow');
  for (let i = 0; i < 4; i++) { type(dom, loadInput(rs[i]), '50'); type(dom, repsInput(rs[i]), '10'); }
  await settle();
  for (let i = 0; i < 4; i++) {
    const row = $$(dom, '.excard')[0].querySelectorAll('.setrow')[i];
    if (!row.classList.contains('done')) await click(dom, row.querySelector('.setcheck'));
  }
  assert.match(text(dom), /4 of 19 working sets/);
  await click(dom, buttonWithText(dom, 'Finish workout'));
  assert.match(text(dom), /Finish Push\?/);
  assert.match(text(dom), /4 of 19 working sets across 1 of 6 exercises/);
  await click(dom, buttonWithText(dom, 'Finish'));
  await waitFor(() => /Increase suggested: 55 lb \(from 50\)/.test(text(dom)), 'summary with suggestion');
  const s3 = CS2.app.store.db.sessions[sid];
  assert.equal(s3.status, 'completed');
  assert.equal($(dom, '#timerbar').hidden, true, 'finishing clears the rest timer');
  assert.match(text(dom), /Hold the load\./); // other exercises: no increase, with reasons available
  await click(dom, buttonWithText(dom, 'Accept 55 lb'));
  assert.match(text(dom), /Accepted — 55 lb will be prefilled next time/);
  await click(dom, buttonWithText(dom, 'Done'));
  await waitFor(() => /1 of 4 sessions this week/.test(text(dom)), 'week ring updated');
  assert.match(text(dom), /You hit the top of the range on all 4 incline dumbbell press sets/);

  // Next Push session (move the finished one to yesterday so a new one can start today)
  CS2.app.store.commit((d) => { d.sessions[sid].localDate = CS2.util.addDays(d.sessions[sid].localDate, -7); });
  await settle();
  await click(dom, $$(dom, '#tabs .tab').find((b) => b.getAttribute('aria-label') === 'Train'));
  const pushRow2 = $$(dom, '.weekrow').find((r) => /Push/.test(r.textContent));
  await click(dom, buttonWithText(dom, 'Start', pushRow2) || buttonWithText(dom, 'Start today', pushRow2));
  await waitFor(() => $$(dom, '.excard').length === 6, 'second logger');
  assert.match(text(dom), /0 of 19 working sets/, 'prefilled sets are not completed');
  const n = CS2.app.store.db.sessions[CS2.app.store.db.sessionOrder[1]];
  assert.equal(n.exercises[0].sets[0].load, 55, 'accepted suggestion prefills 55');
  assert.equal(n.exercises[0].sets[0].reps, 10);
  assert.equal(n.exercises[0].sets.every((x) => !x.completed), true);
  assert.match($$(dom, '.excard')[0].textContent, /Last \(.*\): 50 lb × 10, 10, 10, 10/);
  assert.match($$(dom, '.excard')[0].textContent, /Using suggested 55 lb per dumbbell/);
  assert.equal($$(dom, '.excard')[0].querySelector('input[aria-label^="Load"]').classList.contains('prefilled'), true);
  dom.window.close();
});

test('flow: localStorage backend is used when the preview API is absent; save and reload round-trip', async () => {
  const dom = open(null);
  await waitFor(() => /Step 1 of 5/.test(text(dom)), 'onboarding');
  const CS = dom.window.CS;
  assert.equal(CS.app.store.backend.mode, 'localstorage');
  await click(dom, buttonWithText(dom, 'Confirm 172 lb'));
  for (const label of ['Continue', 'Skip', 'Continue', 'Go to Today']) await click(dom, buttonWithText(dom, label));
  await waitFor(() => CS.app.store.status.state === 'saved', 'saved');
  const raw = dom.window.localStorage.getItem('cs:db');
  assert.ok(raw && raw.length > 100);
  // A second store on the same backend reads the same data (what a reload does)
  const store2 = CS.storage.createStore(CS.app.store.backend);
  const db2 = await store2.load();
  assert.equal(db2.profile.name, 'Brenden');
  assert.equal(CS.db.latestMeasurement(db2, 'weight').value, 172);
  dom.window.close();
});

test('flow: delete all data requires typed confirmation and returns to onboarding', async () => {
  const storage = fakePreviewStorage();
  const dom = open(storage);
  await waitFor(() => /Step 1 of 5/.test(text(dom)), 'onboarding');
  await click(dom, buttonWithText(dom, 'Confirm 172 lb'));
  for (const label of ['Continue', 'Skip', 'Continue', 'Go to Today']) await click(dom, buttonWithText(dom, label));
  await click(dom, $$(dom, '#tabs .tab').find((b) => b.getAttribute('aria-label') === 'Profile'));
  assert.match(text(dom), /Preview storage/);
  await click(dom, buttonWithText(dom, 'Delete all data on this device'));
  const confirmBtn = buttonWithText(dom, 'Delete everything');
  assert.equal(confirmBtn.disabled, true);
  type(dom, $(dom, '.sheet input'), 'DELETE');
  assert.equal(confirmBtn.disabled, false);
  await click(dom, confirmBtn);
  await waitFor(() => /Step 1 of 5/.test(text(dom)), 'back to onboarding');
  assert.equal('cs:db' in storage._store, false);
  dom.window.close();
});

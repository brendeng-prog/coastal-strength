"""Coastal Strength mark: a single rising-tide line whose crest curls into an implied C.
Renders favicon.svg + PNG icons without any SVG rasterizer dependency."""
import os
from PIL import Image, ImageDraw

OUT = os.path.join(os.path.dirname(__file__), '..', 'assets')
os.makedirs(OUT, exist_ok=True)

# One path, viewBox 0 0 64 64. Crest hook -> top arc -> left bulge -> rising tail.
SEGMENTS = [
    ((37.0, 27.5), (46.0, 27.0), (52.0, 18.5), (45.5, 12.0)),
    ((45.5, 12.0), (36.0, 5.0), (17.5, 9.0), (13.5, 24.0)),
    ((13.5, 24.0), (9.5, 40.0), (18.0, 54.0), (34.0, 55.0)),
    ((34.0, 55.0), (43.0, 55.6), (50.5, 50.0), (55.0, 41.0)),
]
PATH_D = 'M37 27.5 C46 27 52 18.5 45.5 12 C36 5 17.5 9 13.5 24 C9.5 40 18 54 34 55 C43 55.6 50.5 50 55 41'


def bezier_points(seg, n=120):
    (x0, y0), (x1, y1), (x2, y2), (x3, y3) = seg
    pts = []
    for i in range(n + 1):
        t = i / n
        u = 1 - t
        x = u**3*x0 + 3*u*u*t*x1 + 3*u*t*t*x2 + t**3*x3
        y = u**3*y0 + 3*u*u*t*y1 + 3*u*t*t*y2 + t**3*y3
        pts.append((x, y))
    return pts


def polyline():
    pts = []
    for seg in SEGMENTS:
        p = bezier_points(seg)
        if pts:
            p = p[1:]
        pts.extend(p)
    return pts


def render(size, bg, stroke, pad_frac=0.0, scale=4, radius_frac=0.0):
    S = size * scale
    img = Image.new('RGBA', (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    if bg:
        if radius_frac:
            d.rounded_rectangle([0, 0, S - 1, S - 1], radius=int(S * radius_frac), fill=bg)
        else:
            d.rectangle([0, 0, S - 1, S - 1], fill=bg)
    glyph = S * (1 - 2 * pad_frac)
    off = S * pad_frac
    k = glyph / 64.0
    pts = [(off + x * k, off + y * k) for x, y in polyline()]
    r = 3.0 * k
    # Stamp circles along a densely sampled path: a clean round-capped stroke with no joint seams.
    dense = []
    for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
        steps = max(1, int(((x1 - x0) ** 2 + (y1 - y0) ** 2) ** 0.5 / max(1.0, r * 0.15)))
        for i in range(steps):
            t = i / steps
            dense.append((x0 + (x1 - x0) * t, y0 + (y1 - y0) * t))
    dense.append(pts[-1])
    for (x, y) in dense:
        d.ellipse([x - r, y - r, x + r, y + r], fill=stroke)
    return img.resize((size, size), Image.LANCZOS)


NAVY = (10, 25, 34, 255)
SEA = (63, 189, 178, 255)

render(512, NAVY, SEA, pad_frac=0.16).save(os.path.join(OUT, 'icon-512.png'))
render(192, NAVY, SEA, pad_frac=0.16).save(os.path.join(OUT, 'icon-192.png'))
render(180, NAVY, SEA, pad_frac=0.16).save(os.path.join(OUT, 'apple-touch-icon.png'))
render(64, None, (14, 34, 49, 255), pad_frac=0.04).save(os.path.join(OUT, 'mark-preview.png'))

svg = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">'
       '<path d="%s" fill="none" stroke="#1F8C84" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/></svg>' % PATH_D)
with open(os.path.join(OUT, 'favicon.svg'), 'w') as f:
    f.write(svg)
with open(os.path.join(OUT, 'mark-path.txt'), 'w') as f:
    f.write(PATH_D)
print('icons written')

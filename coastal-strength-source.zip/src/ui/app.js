/* Coastal Strength — ui/app.js */
(function () {
  const CS = (window.CS = window.CS || {});
  const X = CS.dom, U = CS.util, D = CS.db, B = CS.brand;
  const h = X.h;

  const app = {
    store: null, tab: 'today', params: {}, root: null, tabsEl: null, timerEl: null, statusEl: null,
    tickHandle: null, renderQueued: false, audio: null
  };

  app.today = function () { return U.localDate(Date.now(), app.store.db ? app.store.db.profile.timezone : U.defaultTz()); };

  app.navigate = function (tab, params) {
    app.tab = tab; app.params = params || {};
    app.render();
    window.scrollTo(0, 0);
  };

  app.startSession = function (templateId) {
    const active = D.findActiveSession(app.store.db);
    if (active && active.templateId !== templateId) {
      X.toast(active.templateName + ' is still open. Finish it first.');
      app.navigate('train', { view: 'logger' });
      return;
    }
    app.store.commit((d) => D.startSession(d, templateId, app.today(), new Date().toISOString()));
    app.navigate('train', { view: 'logger' });
  };

  app.storageNote = function () {
    const m = app.store.backend.mode;
    if (m === 'preview') return 'Saved to your claude.ai account for this artifact — not to any server of ours, and not synced to a phone. If this preview is deleted, the data goes with it.';
    if (m === 'indexeddb' || m === 'localstorage') return 'Device- and browser-specific. Clearing site data, using a different browser, or a private window means a different (or empty) copy. This is not cloud sync.';
    return 'Storage is unavailable in this browser, so nothing you log will survive a reload. Check the site-data settings or open the app somewhere else.';
  };

  app.applyTheme = function () {
    const t = app.store && app.store.db ? app.store.db.settings.theme : 'auto';
    if (t === 'auto') document.documentElement.removeAttribute('data-theme');
    else document.documentElement.setAttribute('data-theme', t);
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', getComputedStyle(document.documentElement).getPropertyValue('--surface').trim() || '#0A1922');
  };

  /* ---------- rendering ---------- */
  app.render = function () {
    if (app.renderQueued) return;
    app.renderQueued = true;
    (window.requestAnimationFrame || setTimeout)(() => { app.renderQueued = false; app.renderNow(); });
  };

  app.renderNow = function () {
    const root = app.root;
    X.clear(root);
    const db = app.store.db;
    if (!db || !db.profile || !db.profile.onboarded) {
      app.tabsEl.hidden = true; app.timerEl.hidden = true;
      CS.onboarding.render(root, (input) => {
        app.store.set(D.createInitial(input, new Date().toISOString()));
        app.applyTheme();
        app.navigate('today');
      });
      return;
    }
    app.tabsEl.hidden = false;
    const scr = h('div.screen', { class: db.timer ? 'has-timer' : '' });
    scr.appendChild(h('div.topbar', h('div.brand', B.mark(26), h('span', { text: 'Coastal Strength' })), app.statusEl));
    try {
      if (app.tab === 'today') CS.today.render(scr, app);
      else if (app.tab === 'train') CS.train.render(scr, app, app.params);
      else if (app.tab === 'profile') CS.profile.render(scr, app);
      else if (app.tab === 'progress') later(scr, 'Progress', 'Per-exercise history, the rep-range climb, PRs, measurements and consistency arrive with the history slice. Every set you log now is already kept for it.');
      else if (app.tab === 'nutrition') later(scr, 'Nutrition', 'Protein and food logging arrive with the nutrition slice. Nothing here is estimated in the meantime.');
    } catch (e) {
      scr.appendChild(h('div.card', h('b', { text: 'Something broke while drawing this screen.' }), h('p.small.muted', { text: String(e && e.message || e) })));
      console.error(e);
    }
    root.appendChild(scr);
    app.renderTabs();
    app.renderTimer();
    app.renderStatus(app.store.status);
  };

  function later(scr, title, text) {
    scr.appendChild(h('div.later', h('h1', { text: title }), h('p.muted', { style: { marginTop: '8px' }, text: 'Not built yet.' }), h('p.small.muted', { style: { marginTop: '8px' }, text })));
  }

  app.renderTabs = function () {
    const tabs = [['today', 'Today', X.ICON.today], ['train', 'Train', X.ICON.train], ['progress', 'Progress', X.ICON.progress], ['nutrition', 'Nutrition', X.ICON.nutrition], ['profile', 'Profile', X.ICON.profile]];
    X.clear(app.tabsEl);
    const inner = h('div.inner', { role: 'tablist' });
    tabs.forEach(([id, label, icon]) => {
      inner.appendChild(h('button.tab', { role: 'tab', 'aria-current': app.tab === id ? 'page' : null, 'aria-label': label, onClick: () => app.navigate(id) }, X.svg(icon), h('span', { text: label })));
    });
    app.tabsEl.appendChild(inner);
  };

  app.renderTimer = function () { CS.train.renderTimer(app.timerEl, app); };

  app.renderStatus = function (st) {
    const el = app.statusEl;
    el.className = 'status ' + (app.store.backend.mode === 'memory' ? 'unavailable' : st.state);
    el.textContent = app.store.backend.mode === 'memory' ? 'Not saving' : (st.state === 'saved' ? 'Saved' : st.state === 'saving' ? 'Saving…' : st.state === 'dirty' ? 'Unsaved' : st.state === 'error' ? 'Save failed — retrying' : '');
  };

  /* ---------- per-second tick: elapsed clock + rest timer, no full re-render ---------- */
  app.tick = function () {
    const db = app.store.db;
    if (!db) return;
    const active = D.findActiveSession(db);
    const el = document.getElementById('elapsed');
    if (el && active) el.textContent = U.fmtDuration(D.activeMs(active, Date.now()));
    if (db.timer) {
      const st = D.restState(db, Date.now());
      const clock = document.getElementById('restclock');
      if (clock) clock.textContent = st.done ? 'Rest done' : U.fmtClock(st.remainingSec);
      if (st.done && !db.timer.alerted) {
        app.store.commit((d) => { if (d.timer) d.timer.alerted = true; }, { silent: true });
        app.alert();
        app.renderTimer();
      } else if (app.timerEl.hidden) app.renderTimer();
    } else if (!app.timerEl.hidden) app.renderTimer();
  };

  app.alert = function () {
    const s = app.store.db.settings;
    if (s.restVibrate && navigator.vibrate) { try { navigator.vibrate([180, 90, 180]); } catch (e) { /* ignore */ } }
    if (s.restSound) {
      try {
        const AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return;
        if (!app.audio) app.audio = new AC();
        const ctx = app.audio;
        const t0 = ctx.currentTime;
        [0, 0.22].forEach((off) => {
          const o = ctx.createOscillator(), g = ctx.createGain();
          o.type = 'sine'; o.frequency.value = 880;
          g.gain.setValueAtTime(0.0001, t0 + off); g.gain.exponentialRampToValueAtTime(0.25, t0 + off + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t0 + off + 0.16);
          o.connect(g); g.connect(ctx.destination); o.start(t0 + off); o.stop(t0 + off + 0.18);
        });
      } catch (e) { /* ignore */ }
    }
  };

  app.resetAll = async function () {
    await app.store.clear();
    app.tab = 'today'; app.params = {};
    app.applyTheme();
    app.renderNow();
    X.toast('All data deleted');
  };

  /* ---------- boot ---------- */
  app.boot = async function () {
    app.root = document.getElementById('app');
    app.tabsEl = document.getElementById('tabs');
    app.timerEl = document.getElementById('timerbar');
    app.statusEl = h('span.status', { role: 'status', 'aria-live': 'polite' });
    const backend = await CS.storage.detect();
    app.store = CS.storage.createStore(backend);
    app.store.onChange(() => app.render());
    app.store.onStatus((st) => app.renderStatus(st));
    try { await app.store.load(); } catch (e) { console.error(e); }
    app.applyTheme();
    app.renderNow();
    if (backend.mode === 'memory') X.toast('Storage unavailable — nothing will be saved.', 5000);
    app.tickHandle = setInterval(app.tick, 1000);
    // Offline shell when hosted (not in the single-file preview): fails silently if sw.js isn't served.
    if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) {
      navigator.serviceWorker.register('./sw.js').catch(() => {});
    }
    // Unlock audio on first interaction so the rest-timer beep can play later
    document.addEventListener('pointerdown', () => { try { const AC = window.AudioContext || window.webkitAudioContext; if (AC && !app.audio) app.audio = new AC(); if (app.audio && app.audio.state === 'suspended') app.audio.resume(); } catch (e) { /* ignore */ } }, { once: true, passive: true });
    // Flush on backgrounding / navigation away; re-sync clocks when we come back
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') app.store.flushSync(); else app.tick(); });
    window.addEventListener('pagehide', () => app.store.flushSync());
    window.addEventListener('beforeunload', () => app.store.flushSync());
  };

  CS.app = app;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', app.boot);
  else app.boot();
})();

/* Coastal Strength — ui/train.js */
(function () {
  const CS = (window.CS = window.CS || {});
  const X = CS.dom, U = CS.util, D = CS.db, P = CS.plan, B = CS.brand, PR = CS.progression;
  const h = X.h;
  const TR = {};

  function nowIso() { return new Date().toISOString(); }

  TR.render = function (root, app, params) {
    params = params || {};
    const db = app.store.db;
    const active = D.findActiveSession(db);
    if (params.view === 'summary' && params.sessionId && db.sessions[params.sessionId]) return renderSummary(root, app, db.sessions[params.sessionId]);
    if (params.view === 'week') return renderWeek(root, app);
    if (active) return renderLogger(root, app, active);
    return renderWeek(root, app);
  };

  /* ---------- week list ---------- */
  function renderWeek(root, app) {
    const db = app.store.db;
    const today = app.today();
    const ring = CS.stats.weekRing(db, today);
    const active = D.findActiveSession(db);
    const stack = h('div.stack');
    stack.appendChild(h('h1', { text: 'This week' }));
    if (active) {
      stack.appendChild(h('div.card', h('div.row.between', h('div', h('b', { text: active.templateName + ' in progress' }), h('div.small.muted', { text: U.fmtLocalDate(active.localDate) })), h('button.btn.sm.primary', { onClick: () => app.navigate('train', { view: 'logger' }), text: 'Resume' }))));
    }
    const list = h('div.card');
    ring.days.forEach((d) => {
      const row = h('div.weekrow', { class: d.isToday ? 'today' : '' });
      row.appendChild(h('div', h('div.day', { text: U.WEEKDAY_SHORT[d.key] }), h('div.tiny.muted', { text: U.fmtLocalDate(d.date) })));
      const mid = h('div.grow', h('div', { text: d.templateName }));
      const s = d.sessions.find((x) => x.templateId === d.templateId) || d.sessions[0];
      if (s && s.templateId !== d.templateId) mid.appendChild(h('div.tiny.muted', { text: 'Also: ' + s.templateName + ' (' + s.status.replace('_', ' ') + ')' }));
      row.appendChild(mid);
      const right = h('div.row');
      if (d.kind === 'rest') right.appendChild(h('span.pill.muted', { text: 'Rest' }));
      else if (d.kind === 'cardio_optional') right.appendChild(h('span.pill.muted', { text: 'Optional' }));
      else if (s && s.status === 'completed') {
        right.appendChild(h('span.pill.done', { text: 'Done' }));
        right.appendChild(h('button.btn.xs', { onClick: () => app.navigate('train', { view: 'summary', sessionId: s.id }), text: 'View' }));
      } else if (s && (s.status === 'in_progress' || s.status === 'paused')) {
        right.appendChild(h('button.btn.xs.primary', { onClick: () => app.navigate('train', { view: 'logger' }), text: 'Resume' }));
      } else if (s && s.status === 'skipped') {
        right.appendChild(h('span.pill.muted', { text: 'Skipped' }));
        if (!active) right.appendChild(h('button.btn.xs', { onClick: () => app.startSession(d.templateId), text: 'Start today' }));
      } else if (!active && d.kind === 'lift' || (!active && d.kind === 'conditioning')) {
        const done = ring.days.some((o) => o.sessions.some((x) => x.templateId === d.templateId && x.status === 'completed'));
        if (done) right.appendChild(h('span.pill.done', { text: 'Done' }));
        else right.appendChild(h('button.btn.xs', { class: d.isToday ? 'primary' : '', onClick: () => app.startSession(d.templateId), text: d.isToday ? 'Start' : 'Start today' }));
      }
      row.appendChild(right);
      list.appendChild(row);
    });
    stack.appendChild(list);
    stack.appendChild(h('p.small.muted', { text: '"Start today" logs that session on today\'s date. Moving sessions to other dates, skipping with a reason, and editing the plan going forward arrive with the scheduling slice.' }));
    root.appendChild(stack);
  }

  /* ---------- logger ---------- */
  function renderLogger(root, app, session) {
    const db = app.store.db;
    const sid = session.id;
    const wrap = h('div');

    const head = h('div.logger-head');
    const c = D.counts(session);
    head.appendChild(h('div.row.between',
      h('div', h('h1', { text: session.templateName }), h('div.small.muted', { text: U.fmtLocalDate(session.localDate, { weekday: 'short', month: 'short', day: 'numeric' }) + ' · ' + c.workingDone + ' of ' + c.workingPrescribed + ' working sets' })),
      h('div.row',
        h('span.elapsed', { id: 'elapsed', text: U.fmtDuration(D.activeMs(session, Date.now())) }),
        h('button.btn.icon', { 'aria-label': session.status === 'paused' ? 'Resume workout' : 'Pause workout', onClick: () => {
          app.store.commit((d) => session.status === 'paused' ? D.resumeSession(d, sid, nowIso()) : D.pauseSession(d, sid, nowIso()));
          app.render();
        } }, X.svg(session.status === 'paused' ? X.ICON.play : X.ICON.pause)))));
    if (session.status === 'paused') head.appendChild(h('p.small', { style: { marginTop: '4px', color: 'var(--sand)' }, text: 'Paused — the clock is stopped.' }));
    wrap.appendChild(head);

    const list = h('div.stack');
    session.exercises.forEach((inst) => list.appendChild(exerciseCard(app, session, inst)));
    wrap.appendChild(list);

    wrap.appendChild(h('div.row', { style: { marginTop: '18px' } },
      h('button.btn.quiet', { onClick: () => showEffort(), text: 'Effort & RIR' }),
      h('button.btn.quiet', { onClick: () => app.navigate('train', { view: 'week' }), text: 'See the week' })));
    wrap.appendChild(h('button.btn.primary.block', { style: { marginTop: '12px' }, onClick: () => finishFlow(app, session), text: 'Finish workout' }));
    root.appendChild(wrap);
  }

  function showEffort() {
    X.sheet('Effort', (sh, api) => {
      sh.appendChild(h('p', { text: P.EFFORT_GUIDANCE.short }));
      sh.appendChild(h('p.muted', { style: { marginTop: '10px' }, text: P.EFFORT_GUIDANCE.rir }));
      sh.appendChild(h('p.muted', { style: { marginTop: '10px' }, text: P.EFFORT_GUIDANCE.warmup }));
      sh.appendChild(h('button.btn.block', { style: { marginTop: '14px' }, onClick: api.close, text: 'Close' }));
    });
  }

  function loadHint(ex) {
    return { per_dumbbell: 'per dumbbell', total_bar: 'bar total', machine_stack: 'stack', assistance: 'assist', added: 'added', none: '' }[ex.loadConvention] || '';
  }

  function fmtSets(sets, unit, ex) {
    if (!sets || !sets.length) return null;
    if (ex.type === 'timed') return sets.map((s) => (s.durationSec == null ? '—' : s.durationSec + ' s')).join(', ');
    const loads = sets.map((s) => s.load);
    const same = loads.every((l) => l === loads[0]);
    const reps = sets.map((s) => (s.reps == null ? '—' : s.reps)).join(', ');
    if (ex.loadConvention === 'none') return reps + ' reps';
    if (same) return (loads[0] == null ? '—' : U.fmtLoad(loads[0])) + ' ' + unit + ' × ' + reps;
    return sets.map((s) => (s.load == null ? '—' : U.fmtLoad(s.load)) + '×' + (s.reps == null ? '—' : s.reps)).join(', ') + ' ' + unit;
  }

  function exerciseCard(app, session, inst) {
    const db = app.store.db;
    const sid = session.id;
    const ex = D.exercise(db, inst.exerciseId);
    const p = inst.prescription;
    const card = h('div.card.excard', { class: inst.skipped ? 'skipped' : '', 'data-inst': inst.instanceId });

    const rangeText = ex.type === 'timed' && p.timed ? p.timed.secMin + '–' + p.timed.secMax + ' s' : p.repMin + '–' + p.repMax;
    const headL = h('div.grow',
      h('div.exname', { text: ex.name }),
      h('div.exmeta', { text: p.sets + ' × ' + rangeText + (p.perSide ? ' per side' : '') + ' · rest ' + U.fmtClock(inst.restSec) + (inst.substitutedFrom ? ' · in place of ' + D.exercise(db, inst.substitutedFrom).name : '') }));
    if (ex.cues) headL.appendChild(h('div.tiny.muted', { style: { marginTop: '3px' }, text: ex.cues }));
    card.appendChild(h('div.exhead', headL, h('button.btn.icon.xs', { 'aria-label': 'More options for ' + ex.name, onClick: () => exerciseMenu(app, session, inst) }, X.svg(X.ICON.more))));

    if (inst.skipped) {
      card.appendChild(h('div.row.between', { style: { marginTop: '8px' } }, h('span.small.muted', { text: 'Skipped' + (inst.skipReason ? ' — ' + inst.skipReason : '') }), h('button.btn.xs', { onClick: () => { app.store.commit((d) => D.unskipExercise(d, sid, inst.instanceId)); app.render(); }, text: 'Undo skip' })));
      return card;
    }

    // Last time
    const lp = inst.lastPerformance;
    const unit = (inst.sets[0] && inst.sets[0].unit) || db.profile.units;
    if (lp && lp.sets.length) card.appendChild(h('div.lastline', { text: 'Last (' + U.fmtLocalDate(lp.localDate) + '): ' + fmtSets(lp.sets, lp.sets[0].unit || unit, ex) }));
    else card.appendChild(h('div.lastline', { text: 'No history yet. Start light and find the range.' }));

    // Suggestion
    const sg = inst.suggestionKey ? db.suggestions[inst.suggestionKey] : null;
    const anyDone = inst.sets.some((s) => s.completed);
    if (sg && sg.result && (sg.result.status === 'increase' || sg.result.status === 'assist_decrease') && sg.result.suggestedLoad != null) {
      const label = (sg.result.status === 'assist_decrease' ? 'Suggested assistance: ' : 'Suggested: ') + U.fmtLoad(sg.result.suggestedLoad) + ' ' + sg.result.unit + ' ' + loadHint(ex);
      const box = h('div.sugg');
      if (!sg.decision) {
        box.appendChild(h('div', { text: label }));
        box.appendChild(h('div.row', { style: { marginTop: '6px' } },
          h('button.btn.xs.primary', { onClick: () => {
            app.store.commit((d) => {
              D.decideSuggestion(d, sg.key, 'accepted');
              const i2 = D.instance(d, sid, inst.instanceId);
              i2.sets.forEach((s) => { if (!s.completed && s.kind === 'working') { s.load = sg.result.suggestedLoad; s.prefilled = true; } });
            });
            app.render();
          }, text: 'Use it' }),
          h('button.btn.xs', { onClick: () => { app.store.commit((d) => D.decideSuggestion(d, sg.key, 'dismissed')); app.render(); }, text: 'Not now' }),
          h('button.btn.xs', { onClick: () => showReasons(ex, sg.result), text: 'Why?' })));
      } else if (sg.decision === 'accepted' || sg.decision === 'overridden') {
        box.appendChild(h('div.row.between', h('span', { text: (sg.decision === 'accepted' ? 'Using suggested ' : 'Using your ') + U.fmtLoad(sg.appliedLoad) + ' ' + sg.unit + ' ' + loadHint(ex) }), h('button.btn.xs', { onClick: () => showReasons(ex, sg.result), text: 'Why?' })));
      }
      if (box.childNodes.length) card.appendChild(box);
    }

    // Sets
    const usesLoad = ex.loadConvention !== 'none';
    const timed = ex.type === 'timed';
    const setsEl = h('div.sets');
    setsEl.appendChild(h('div.sethead', h('span', { text: 'Set' }), h('span', { text: usesLoad ? 'Load · ' + loadHint(ex) : '' }), h('span', { text: timed ? 'Seconds' : 'Reps ' + (p.repMin != null ? p.repMin + '–' + p.repMax : '') }), h('span', { text: 'RIR' }), h('span', { text: 'Done' })));
    let workingIdx = 0, warmIdx = 0;
    const pairIdx = {};
    inst.sets.forEach((s) => {
      let label;
      if (s.kind === 'warmup') { if (s.side !== 'R') warmIdx++; label = 'W' + warmIdx; }
      else {
        if (s.pairId) { if (!(s.pairId in pairIdx)) pairIdx[s.pairId] = ++workingIdx; label = String(pairIdx[s.pairId]); }
        else label = String(++workingIdx);
      }
      setsEl.appendChild(setRow(app, session, inst, ex, s, label));
    });
    card.appendChild(setsEl);

    const acts = h('div.setactions');
    acts.appendChild(h('button.btn.xs', { onClick: () => { app.store.commit((d) => D.addSet(d, sid, inst.instanceId, 'working')); rerenderCard(app, session, inst); }, text: '+ Set' }));
    acts.appendChild(h('button.btn.xs', { onClick: () => { app.store.commit((d) => D.addSet(d, sid, inst.instanceId, 'warmup')); rerenderCard(app, session, inst); }, text: '+ Warm-up' }));
    acts.appendChild(h('button.btn.xs', { onClick: () => notesSheet(app, session, inst), text: inst.notes ? 'Notes ✓' : 'Notes' }));
    if (ex.type === 'barbell') acts.appendChild(h('button.btn.xs', { onClick: () => plateSheet(app, inst, unit), text: 'Plates' }));
    card.appendChild(acts);
    return card;
  }

  function rerenderCard(app, session, inst) {
    const db = app.store.db;
    const s2 = db.sessions[session.id];
    const i2 = s2.exercises.find((e) => e.instanceId === inst.instanceId);
    const old = document.querySelector('[data-inst="' + inst.instanceId + '"]');
    if (!old || !i2) { app.render(); return; }
    old.replaceWith(exerciseCard(app, s2, i2));
    const c = D.counts(s2);
    const meta = document.querySelector('.logger-head .small.muted');
    if (meta) meta.textContent = U.fmtLocalDate(s2.localDate, { weekday: 'short', month: 'short', day: 'numeric' }) + ' · ' + c.workingDone + ' of ' + c.workingPrescribed + ' working sets';
  }

  function setRow(app, session, inst, ex, s, label) {
    const db = app.store.db;
    const sid = session.id, iid = inst.instanceId;
    const p = inst.prescription;
    const usesLoad = ex.loadConvention !== 'none';
    const timed = ex.type === 'timed';
    const row = h('div.setrow', { class: (s.completed ? 'done ' : '') + (s.kind === 'warmup' ? 'warm' : '') });

    const lbl = h('button.setlabel', { type: 'button', style: { background: 'none', border: 0, padding: 0 }, 'aria-label': (s.kind === 'warmup' ? 'Warm-up set ' : 'Working set ') + label + (s.side !== 'both' ? ' ' + s.side : '') + '. Tap to switch between warm-up and working.', onClick: () => {
      app.store.commit((d) => D.setKind(d, sid, iid, s.id, s.kind === 'warmup' ? 'working' : 'warmup'));
      rerenderCard(app, session, inst);
    } }, h('b', { text: label + (s.side !== 'both' ? ' ' + s.side : '') }), h('span', { text: s.kind === 'warmup' ? 'warm' : '' }));
    row.appendChild(lbl);

    const silent = (fn) => app.store.commit(fn, { silent: true });
    if (usesLoad) {
      const inp = X.numInput({ value: s.load, cls: 'setinput' + (s.prefilled ? ' prefilled' : ''), placeholder: '—', max: 5000, label: 'Load for set ' + label, onValue: (v) => silent((d) => D.setField(d, sid, iid, s.id, 'load', v)) });
      row.appendChild(inp);
    } else row.appendChild(h('div.convention', { text: ex.type === 'timed' ? '' : 'bodyweight' }));

    if (timed) row.appendChild(X.numInput({ value: s.durationSec, integer: true, cls: 'setinput' + (s.prefilled ? ' prefilled' : ''), placeholder: p.timed ? p.timed.secMin + '–' + p.timed.secMax : 's', max: 3600, label: 'Seconds for set ' + label, onValue: (v) => silent((d) => D.setField(d, sid, iid, s.id, 'durationSec', v)) }));
    else row.appendChild(X.numInput({ value: s.reps, integer: true, cls: 'setinput' + (s.prefilled ? ' prefilled' : ''), placeholder: p.repMin != null ? p.repMin + '–' + p.repMax : 'reps', max: 999, label: 'Reps for set ' + label, onValue: (v) => silent((d) => D.setField(d, sid, iid, s.id, 'reps', v)) }));

    row.appendChild(X.numInput({ value: s.rir, integer: true, cls: 'setinput rir', placeholder: '–', max: 10, label: 'Reps in reserve for set ' + label, onValue: (v) => silent((d) => D.setField(d, sid, iid, s.id, 'rir', v)) }));

    const chk = h('button.setcheck', { class: s.completed ? 'on' : '', type: 'button', 'aria-pressed': s.completed ? 'true' : 'false', 'aria-label': (s.completed ? 'Undo set ' : 'Complete set ') + label, onClick: () => {
      let nowDone = false;
      app.store.commit((d) => {
        nowDone = D.toggleComplete(d, sid, iid, s.id, nowIso());
        if (nowDone && d.settings.autoStartRest && s.kind === 'working') D.startRest(d, inst.restSec, Date.now(), sid);
      });
      rerenderCard(app, session, inst);
      app.renderTimer();
    } }, X.svg(X.ICON.check));
    row.appendChild(chk);
    return row;
  }

  function showReasons(ex, result) {
    X.sheet(ex.name, (sh, api) => {
      sh.appendChild(h('p', { text: headline(result) }));
      const ul = h('ul.reasons');
      (result.reasons || []).forEach((r) => ul.appendChild(h('li', { text: r })));
      sh.appendChild(ul);
      if (result.decline) sh.appendChild(h('p.small', { style: { marginTop: '10px' }, text: result.decline }));
      sh.appendChild(h('button.btn.block', { style: { marginTop: '14px' }, onClick: api.close, text: 'Close' }));
    });
  }

  function headline(r) {
    switch (r.status) {
      case 'increase': return 'Increase suggested: ' + U.fmtLoad(r.suggestedLoad) + ' ' + r.unit + ' (from ' + U.fmtLoad(r.currentLoad) + ').';
      case 'assist_decrease': return r.suggestedLoad == null ? 'Assistance is already 0.' : 'Less assistance suggested: ' + U.fmtLoad(r.suggestedLoad) + ' ' + r.unit + ' (from ' + U.fmtLoad(r.currentLoad) + ').';
      case 'bodyweight_top': return 'Top of the range on every set.';
      case 'timed_top': return 'Upper bound reached on every hold.';
      case 'not_evaluated': return 'Not evaluated.';
      default: return 'Hold the load.';
    }
  }

  function exerciseMenu(app, session, inst) {
    const db = app.store.db;
    const sid = session.id, iid = inst.instanceId;
    const ex = D.exercise(db, inst.exerciseId);
    const anyDone = inst.sets.some((s) => s.completed);
    const idx = session.exercises.findIndex((e) => e.instanceId === iid);
    X.actionSheet(ex.name, [
      !inst.skipped && { label: 'Skip this exercise', onSelect: async () => {
        const reason = await X.prompt({ title: 'Skip ' + ex.name, placeholder: 'Reason (optional)', confirmLabel: 'Skip' });
        if (reason === null) return;
        app.store.commit((d) => D.skipExercise(d, sid, iid, reason.trim()));
        app.render();
      } },
      { label: 'Substitute', hint: anyDone ? 'Not after logging sets' : (inst.substitutedFrom ? 'Currently a substitute' : ''), onSelect: () => {
        if (anyDone) { X.toast('Sets are already logged for this exercise. Add a new exercise instead — coming with plan editing.'); return; }
        substituteSheet(app, session, inst);
      } },
      ex.unilateral && { label: inst.sidesSeparate ? 'Log both sides as one row' : 'Log left and right separately', onSelect: () => { app.store.commit((d) => D.setSidesSeparate(d, sid, iid, !inst.sidesSeparate)); app.render(); } },
      { label: 'Remove a set', onSelect: () => removeSetSheet(app, session, inst) },
      idx > 0 && { label: 'Move up (this session only)', onSelect: () => { app.store.commit((d) => D.moveExercise(d, sid, iid, -1)); app.render(); } },
      idx < session.exercises.length - 1 && { label: 'Move down (this session only)', onSelect: () => { app.store.commit((d) => D.moveExercise(d, sid, iid, 1)); app.render(); } },
      { label: 'Rest timer for this exercise', hint: U.fmtClock(inst.restSec), onSelect: async () => {
        const v = await X.prompt({ title: 'Rest after each set (seconds)', value: String(inst.restSec), inputmode: 'numeric', help: 'A default, not a rule. Starts automatically when you complete a working set.' });
        if (v === null) return;
        const r = U.parseNum(v, { integer: true, max: 3600 });
        if (r.error || r.value == null) { X.toast(r.error || 'Enter seconds.'); return; }
        app.store.commit((d) => D.setInstanceField(d, sid, iid, 'restSec', r.value));
        app.render();
      } },
      { label: 'Edit cues', onSelect: async () => {
        const v = await X.prompt({ title: 'Cues for ' + ex.name, value: ex.cues || '', multiline: true });
        if (v === null) return;
        app.store.commit((d) => { if (d.exercises[ex.id]) d.exercises[ex.id].cues = v.trim(); });
        app.render();
      } }
    ]);
  }

  function substituteSheet(app, session, inst) {
    const db = app.store.db;
    const ex = D.exercise(db, inst.exerciseId);
    const all = Object.values(db.exercises).filter((e) => e.id !== ex.id);
    const family = all.filter((e) => e.family && e.family === ex.family);
    const rest = all.filter((e) => family.indexOf(e) < 0).sort((a, b) => a.name.localeCompare(b.name));
    X.sheet('Substitute ' + ex.name, (sh, api) => {
      sh.appendChild(h('p.help', { style: { marginBottom: '8px' }, text: 'The substitute keeps its own history and progression. This session only.' }));
      const list = h('div.list');
      const add = (e, hint) => list.appendChild(h('button', { onClick: () => { api.close(); app.store.commit((d) => D.substituteExercise(d, session.id, inst.instanceId, e.id)); app.render(); } }, h('span', { text: e.name }), h('span.small.muted', { text: hint || '' })));
      family.forEach((e) => add(e, 'same movement'));
      rest.forEach((e) => add(e, ''));
      sh.appendChild(list);
      sh.appendChild(h('button.btn.block', { style: { marginTop: '10px' }, onClick: api.close, text: 'Cancel' }));
    });
  }

  function removeSetSheet(app, session, inst) {
    const db = app.store.db;
    const ex = D.exercise(db, inst.exerciseId);
    X.sheet('Remove a set', (sh, api) => {
      const list = h('div.list');
      const seen = {};
      inst.sets.forEach((s, i) => {
        if (s.pairId && seen[s.pairId]) return;
        if (s.pairId) seen[s.pairId] = true;
        const desc = (s.kind === 'warmup' ? 'Warm-up' : 'Set') + ' ' + (i + 1) + ': ' + (s.load != null ? U.fmtLoad(s.load) + ' ' + s.unit + ' × ' : '') + (s.reps != null ? s.reps : s.durationSec != null ? s.durationSec + ' s' : '—') + (s.completed ? ' · done' : '');
        list.appendChild(h('button', { class: s.completed ? 'danger' : '', onClick: async () => {
          if (s.completed) { const ok = await X.confirm({ title: 'Remove a completed set?', body: 'This deletes the logged set from ' + ex.name + '.', confirmLabel: 'Remove', danger: true }); if (!ok) return; }
          api.close();
          app.store.commit((d) => D.deleteSet(d, session.id, inst.instanceId, s.id));
          rerenderCard(app, session, inst);
        } }, h('span', { text: desc })));
      });
      sh.appendChild(list);
      sh.appendChild(h('button.btn.block', { style: { marginTop: '10px' }, onClick: api.close, text: 'Cancel' }));
    });
  }

  function notesSheet(app, session, inst) {
    X.prompt({ title: 'Notes', value: inst.notes || '', multiline: true, placeholder: 'Seat position, grip, how it felt…' }).then((v) => {
      if (v === null) return;
      app.store.commit((d) => D.setInstanceField(d, session.id, inst.instanceId, 'notes', v.trim()));
      rerenderCard(app, session, inst);
    });
  }

  function plateSheet(app, inst, unit) {
    const bars = X.BARS[unit], plates = X.PLATES[unit];
    let target = (inst.sets.find((s) => s.kind === 'working' && s.load != null) || {}).load || null;
    let bar = bars[0];
    X.sheet('Plate math', (sh, api) => {
      const out = h('div', { style: { marginTop: '12px' } });
      function calc() {
        X.clear(out);
        const r = X.plateMath(target, bar, plates);
        if (target == null) { out.appendChild(h('p.muted', { text: 'Enter a target total.' })); return; }
        if (target < bar) { out.appendChild(h('p.muted', { text: 'Target is below the bar weight.' })); return; }
        out.appendChild(h('p', h('b', { text: 'Per side: ' }), r.perSide.length ? r.perSide.map(U.fmtLoad).join(' + ') + ' ' + unit : 'empty bar'));
        if (!r.exact) out.appendChild(h('p.small.muted', { text: U.fmtLoad(r.remainder) + ' ' + unit + ' per side can\'t be made with these plates. Loaded total: ' + U.fmtLoad(bar + 2 * r.perSide.reduce((a, b) => a + b, 0)) + ' ' + unit + '.' }));
      }
      sh.appendChild(h('div.field', h('label', { text: 'Target total (' + unit + ')' }), X.numInput({ value: target, cls: 'setinput', max: 5000, label: 'Target total', onValue: (v) => { target = v; calc(); } })));
      const bc = h('div.chips', { style: { marginTop: '10px' } });
      bars.forEach((b) => bc.appendChild(h('button.chip.sm', { type: 'button', 'aria-pressed': b === bar ? 'true' : 'false', onClick: () => { bar = b; bc.querySelectorAll('.chip').forEach((c) => c.setAttribute('aria-pressed', c.textContent.startsWith(String(b)) ? 'true' : 'false')); calc(); }, text: b + ' ' + unit + ' bar' })));
      sh.appendChild(bc);
      sh.appendChild(out);
      sh.appendChild(h('p.tiny.muted', { style: { marginTop: '8px' }, text: 'Plates: ' + plates.join(', ') + ' ' + unit + '.' }));
      sh.appendChild(h('button.btn.block', { style: { marginTop: '14px' }, onClick: api.close, text: 'Close' }));
      calc();
    });
  }

  /* ---------- finish ---------- */
  function finishFlow(app, session) {
    const c = D.counts(session);
    const body = c.workingDone === 0
      ? 'No working sets are logged. Finishing records the session with nothing completed — it will not count toward the week or progression.'
      : c.workingDone + ' of ' + c.workingPrescribed + ' working sets across ' + c.exercisesDone + ' of ' + c.exercisesTotal + ' exercises. Sets you didn\'t complete stay incomplete.';
    X.confirm({ title: 'Finish ' + session.templateName + '?', body, confirmLabel: 'Finish' }).then((ok) => {
      if (!ok) return;
      app.store.commit((d) => D.finishSession(d, session.id, nowIso()));
      app.navigate('train', { view: 'summary', sessionId: session.id });
    });
  }

  /* ---------- completion summary ---------- */
  function topSet(sets) {
    let best = null;
    sets.forEach((s) => {
      if (!best) { best = s; return; }
      const a = s.load == null ? -1 : s.load, b = best.load == null ? -1 : best.load;
      if (a > b || (a === b && (s.reps || 0) > (best.reps || 0))) best = s;
    });
    return best;
  }

  function renderSummary(root, app, session) {
    const db = app.store.db;
    const c = D.counts(session);
    const wrap = h('div.stack.summ');
    wrap.appendChild(h('div', h('h1', { text: session.templateName }), h('div.small.muted', { text: U.fmtLocalDate(session.localDate, { weekday: 'long', month: 'short', day: 'numeric' }) })));

    const stats = h('div.card', h('div.row', { style: { justifyContent: 'space-between' } },
      h('div', h('div.stat', { text: String(c.workingDone) }), h('div.tiny.muted', { text: 'working sets of ' + c.workingPrescribed })),
      h('div', h('div.stat', { text: c.exercisesDone + '/' + c.exercisesTotal }), h('div.tiny.muted', { text: 'exercises complete' })),
      h('div', h('div.stat', { text: U.fmtDuration(D.activeMs(session, Date.now())) }), h('div.tiny.muted', { text: 'active time' }))));
    if (c.warmupsDone) stats.appendChild(h('p.tiny.muted', { style: { marginTop: '8px' }, text: c.warmupsDone + ' warm-up set(s) logged, excluded from the counts above.' }));
    wrap.appendChild(stats);

    // Comparison with the previous completed session of the same template
    const prev = D.sessionList(db).filter((s) => s.id !== session.id && s.templateId === session.templateId && s.status === 'completed' && s.finishedAt < (session.finishedAt || '9')).slice(-1)[0];
    const cmp = h('div.card');
    cmp.appendChild(h('h3', { text: prev ? 'Compared with ' + U.fmtLocalDate(prev.localDate) : 'First ' + session.templateName + ' session' }));
    if (prev) {
      const grid = h('div.cmp', { style: { marginTop: '10px' } }, h('span.h', { text: 'Top working set' }), h('span.h', { text: U.fmtLocalDate(prev.localDate) }), h('span.h', { text: 'Today' }));
      session.exercises.forEach((inst) => {
        if (inst.skipped) return;
        const ex = D.exercise(db, inst.exerciseId);
        const now = topSet(D.logicalSets(inst, { completedOnly: true, kind: 'working' }));
        const pi = prev.exercises.find((e) => e.exerciseId === inst.exerciseId && !e.skipped);
        const then = pi ? topSet(D.logicalSets(pi, { completedOnly: true, kind: 'working' })) : null;
        const f = (s) => !s ? '—' : ex.type === 'timed' ? (s.durationSec == null ? '—' : s.durationSec + ' s') : (s.load != null ? U.fmtLoad(s.load) + ' × ' : '') + (s.reps == null ? '—' : s.reps);
        grid.appendChild(h('span', { text: ex.name })); grid.appendChild(h('span.muted', { text: f(then) })); grid.appendChild(h('span', { text: f(now) }));
      });
      cmp.appendChild(grid);
      const pc = D.counts(prev);
      cmp.appendChild(h('p.small.muted', { style: { marginTop: '10px' }, text: 'Working sets ' + pc.workingDone + ' → ' + c.workingDone + '. Active time ' + U.fmtDuration(D.activeMs(prev, Date.now())) + ' → ' + U.fmtDuration(D.activeMs(session, Date.now())) + '.' }));
    } else cmp.appendChild(h('p.small.muted', { style: { marginTop: '6px' }, text: 'Nothing to compare against yet.' }));
    wrap.appendChild(cmp);

    // Progression decisions
    const sugg = session.exercises.map((inst) => ({ inst, sg: db.suggestions[session.id + ':' + inst.instanceId] })).filter((x) => x.sg);
    if (sugg.length) {
      const sc = h('div.card');
      sc.appendChild(h('h3', { text: 'Next time' }));
      sugg.forEach(({ inst, sg }) => {
        const ex = D.exercise(db, inst.exerciseId);
        const r = sg.result;
        if (r.status === 'not_evaluated') return;
        const item = h('div', { style: { marginTop: '12px', paddingTop: '12px', borderTop: '1px solid var(--line)' } });
        item.appendChild(h('div.row.between', h('b', { text: ex.name }), h('button.btn.xs', { onClick: () => showReasons(ex, r), text: 'Why?' })));
        item.appendChild(h('p.small', { style: { marginTop: '4px' }, text: headline(r) }));
        if (r.rirFlag) item.appendChild(h('p.small', { style: { marginTop: '4px', color: 'var(--sand)' }, text: 'Logged at 0 RIR — holding the load may be appropriate.' }));
        if (r.decline) item.appendChild(h('p.small.muted', { style: { marginTop: '4px' }, text: r.decline }));
        if ((r.status === 'increase' || r.status === 'assist_decrease') && r.suggestedLoad != null) {
          const controls = h('div.row.wrap', { style: { marginTop: '8px' } });
          if (!sg.decision) {
            controls.appendChild(h('button.btn.xs.primary', { onClick: () => { app.store.commit((d) => D.decideSuggestion(d, sg.key, 'accepted')); app.render(); }, text: 'Accept ' + U.fmtLoad(r.suggestedLoad) + ' ' + r.unit }));
            controls.appendChild(h('button.btn.xs', { onClick: () => { app.store.commit((d) => D.decideSuggestion(d, sg.key, 'dismissed')); app.render(); }, text: 'Dismiss' }));
            controls.appendChild(h('button.btn.xs', { onClick: async () => {
              const v = await X.prompt({ title: 'Load to use next time (' + r.unit + ')', value: String(r.suggestedLoad), inputmode: 'decimal', confirmLabel: 'Use this' });
              if (v === null) return;
              const n = U.parseNum(v, { max: 5000 });
              if (n.error || n.value == null) { X.toast(n.error || 'Enter a load.'); return; }
              app.store.commit((d) => D.decideSuggestion(d, sg.key, 'overridden', n.value));
              app.render();
            }, text: 'Override…' }));
          } else {
            controls.appendChild(h('span.small.muted', { text: sg.decision === 'accepted' ? 'Accepted — ' + U.fmtLoad(sg.appliedLoad) + ' ' + sg.unit + ' will be prefilled next time.' : sg.decision === 'overridden' ? 'Using ' + U.fmtLoad(sg.appliedLoad) + ' ' + sg.unit + ' next time.' : 'Dismissed — last load stays.' }));
            controls.appendChild(h('button.btn.xs', { onClick: () => { app.store.commit((d) => { const g = d.suggestions[sg.key]; g.decision = null; g.appliedLoad = null; }); app.render(); }, text: 'Change' }));
          }
          item.appendChild(controls);
        }
        sc.appendChild(item);
      });
      sc.appendChild(h('p.tiny.muted', { style: { marginTop: '12px' }, text: 'Suggestions never rewrite the next workout. Undecided ones show up again at the start of the next session.' }));
      wrap.appendChild(sc);
    }

    // Optional feedback
    const fb = h('div.card');
    fb.appendChild(h('h3', { text: 'Optional' }));
    [['energy', 'Energy'], ['difficulty', 'Difficulty'], ['soreness', 'Soreness']].forEach(([k, label]) => {
      const sc = h('div.scale');
      for (let i = 1; i <= 5; i++) sc.appendChild(h('button.chip', { type: 'button', 'aria-pressed': session[k] === i ? 'true' : 'false', onClick: () => { app.store.commit((d) => D.setSessionField(d, session.id, k, session[k] === i ? null : i)); app.render(); }, text: String(i) }));
      fb.appendChild(h('div.field', { style: { marginTop: '10px' } }, h('label', { text: label + ' (1 low – 5 high)' }), sc));
    });
    fb.appendChild(h('div.field', { style: { marginTop: '10px' } }, h('label', { text: 'Notes' }), h('textarea.input', { 'aria-label': 'Session notes', onInput: (e) => app.store.commit((d) => D.setSessionField(d, session.id, 'notes', e.target.value), { silent: true }) }, session.notes || '')));
    wrap.appendChild(fb);

    wrap.appendChild(h('button.btn.primary.block', { onClick: () => app.navigate('today'), text: 'Done' }));
    root.appendChild(wrap);
  }

  /* ---------- rest timer bar ---------- */
  TR.renderTimer = function (bar, app) {
    const db = app.store.db;
    X.clear(bar);
    if (!db || !db.timer) { bar.hidden = true; return; }
    const st = D.restState(db, Date.now());
    bar.hidden = false;
    bar.className = 'timerbar' + (st.done ? ' done' : '');
    const inner = h('div.inner');
    const frac = st.durationSec ? Math.max(0, Math.min(1, 1 - st.remainingSec / st.durationSec)) : 0;
    bar.appendChild(h('div.bar', { style: { width: (frac * 100).toFixed(1) + '%' } }));
    inner.appendChild(h('div.clock', { id: 'restclock', 'aria-live': 'off', text: st.done ? 'Rest done' : U.fmtClock(st.remainingSec) }));
    inner.appendChild(h('div.grow.tiny.muted', { text: st.done ? 'Next set when ready.' : (st.paused ? 'Paused' : 'Rest') }));
    inner.appendChild(h('button.btn.xs', { 'aria-label': 'Shorten by 30 seconds', onClick: () => { app.store.commit((d) => D.adjustRest(d, -30, Date.now())); app.renderTimer(); }, text: '−30' }));
    inner.appendChild(h('button.btn.xs', { 'aria-label': 'Extend by 30 seconds', onClick: () => { app.store.commit((d) => D.adjustRest(d, 30, Date.now())); app.renderTimer(); }, text: '+30' }));
    inner.appendChild(h('button.btn.xs.icon', { 'aria-label': st.paused ? 'Resume rest timer' : 'Pause rest timer', onClick: () => { app.store.commit((d) => st.paused ? D.resumeRest(d, Date.now()) : D.pauseRest(d, Date.now())); app.renderTimer(); } }, X.svg(st.paused ? X.ICON.play : X.ICON.pause)));
    inner.appendChild(h('button.btn.xs.icon', { 'aria-label': 'Dismiss rest timer', onClick: () => { app.store.commit((d) => D.dismissRest(d)); app.renderTimer(); } }, X.svg(X.ICON.close)));
    bar.appendChild(inner);
  };

  CS.train = TR;
})();

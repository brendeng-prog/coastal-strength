/* Coastal Strength — ui/profile.js */
(function () {
  const CS = (window.CS = window.CS || {});
  const X = CS.dom, U = CS.util, D = CS.db, P = CS.plan;
  const h = X.h;
  const PF = {};

  PF.render = function (root, app) {
    const db = app.store.db;
    const pr = db.profile;
    const stack = h('div.stack');
    stack.appendChild(h('h1', { text: 'Profile' }));

    /* You */
    const you = h('div.card.stack');
    you.appendChild(h('h3', { text: 'You' }));
    you.appendChild(field('Name', h('input.input', { type: 'text', value: pr.name, 'aria-label': 'Name', onChange: (e) => app.store.commit((d) => { d.profile.name = e.target.value.trim(); }) })));
    const hIn = pr.heightIn;
    you.appendChild(field('Height', h('div.row',
      X.numInput({ value: hIn == null ? null : (pr.units === 'lb' ? Math.round(hIn * 10) / 10 : Math.round(hIn * 2.54)), max: 300, label: 'Height', onValue: (v) => app.store.commit((d) => { d.profile.heightIn = v == null ? null : (d.profile.units === 'lb' ? v : v / 2.54); }, { silent: true }) }),
      h('span.muted', { text: pr.units === 'lb' ? 'in' : 'cm' }))));
    you.appendChild(field('Units', chips([['lb', 'lb'], ['kg', 'kg']], pr.units, (v) => { app.store.commit((d) => { d.profile.units = v; }); app.render(); }), 'Logged sets keep the unit they were logged in; prefill converts.'));
    const tzSel = h('select.input', { 'aria-label': 'Time zone', onChange: (e) => { app.store.commit((d) => { d.profile.timezone = e.target.value; }); app.render(); } });
    let zones = [];
    try { zones = Intl.supportedValuesOf('timeZone'); } catch (e) { zones = [pr.timezone]; }
    if (zones.indexOf(pr.timezone) < 0) zones.unshift(pr.timezone);
    zones.forEach((z) => tzSel.appendChild(h('option', { value: z, selected: z === pr.timezone, text: z })));
    you.appendChild(field('Time zone', tzSel));
    you.appendChild(field('Nutrition mode', chips([['maintenance', 'Maintenance / recomp'], ['gain', 'Gradual gain'], ['loss', 'Gradual fat loss'], ['undecided', 'Undecided']], pr.nutritionMode, (v) => { app.store.commit((d) => { d.profile.nutritionMode = v; }); app.render(); })));
    you.appendChild(field('Limitations', h('textarea.input', { 'aria-label': 'Limitations', onChange: (e) => app.store.commit((d) => { d.profile.limitations = e.target.value; }) }, pr.limitations || '')));
    stack.appendChild(you);

    /* Schedule */
    const sched = h('div.card.stack');
    sched.appendChild(h('h3', { text: 'Week' }));
    const plan = D.activePlan(db).templates;
    ['push', 'pull', 'legs', 'upper', 'zone2', 'conditioning'].forEach((tid) => {
      const sel = h('select.input', { 'aria-label': plan[tid].name + ' day', onChange: (e) => {
        const wd = e.target.value || null;
        const clash = wd && Object.keys(pr.schedule).find((t) => t !== tid && pr.schedule[t] === wd);
        if (clash) { X.toast(plan[clash].name + ' is already on ' + U.WEEKDAY_LABEL[wd] + '.'); app.render(); return; }
        app.store.commit((d) => { d.profile.schedule[tid] = wd; }); app.render();
      } });
      sel.appendChild(h('option', { value: '', selected: !pr.schedule[tid], text: 'Not scheduled' }));
      U.WEEKDAYS.forEach((wd) => sel.appendChild(h('option', { value: wd, selected: pr.schedule[tid] === wd, text: U.WEEKDAY_LABEL[wd] })));
      sched.appendChild(field(plan[tid].name, sel));
    });
    sched.appendChild(h('p.help', { text: 'Changes the plan going forward. Completed sessions are never rewritten.' }));
    stack.appendChild(sched);

    /* Picks */
    const picks = h('div.card.stack');
    picks.appendChild(h('h3', { text: 'Plan choices' }));
    P.OR_SLOTS.forEach((s) => {
      picks.appendChild(field(s.label, chips(s.options.map((id) => [id, P.EXERCISE_MAP[id].name]), pr.picks[s.slotId], (v) => { app.store.commit((d) => { d.profile.picks[s.slotId] = v; }); app.render(); })));
    });
    picks.appendChild(h('p.help', { text: 'Applies to sessions started from now on. Each option keeps its own history.' }));
    stack.appendChild(picks);

    /* Rest timer */
    const rest = h('div.card.stack');
    rest.appendChild(h('h3', { text: 'Rest timer' }));
    rest.appendChild(field('Auto-start when a working set is completed', chips([['on', 'On'], ['off', 'Off']], db.settings.autoStartRest ? 'on' : 'off', (v) => { app.store.commit((d) => { d.settings.autoStartRest = v === 'on'; }); app.render(); })));
    rest.appendChild(field('Default after compounds (seconds)', X.numInput({ value: db.settings.restDefaults.compound, integer: true, max: 3600, label: 'Compound rest seconds', onValue: (v) => { if (v != null) app.store.commit((d) => { d.settings.restDefaults.compound = v; }, { silent: true }); } })));
    rest.appendChild(field('Default after isolation (seconds)', X.numInput({ value: db.settings.restDefaults.isolation, integer: true, max: 3600, label: 'Isolation rest seconds', onValue: (v) => { if (v != null) app.store.commit((d) => { d.settings.restDefaults.isolation = v; }, { silent: true }); } })));
    rest.appendChild(field('When the timer ends', h('div.chips',
      h('button.chip', { type: 'button', 'aria-pressed': db.settings.restSound ? 'true' : 'false', onClick: () => { app.store.commit((d) => { d.settings.restSound = !d.settings.restSound; }); app.render(); }, text: 'Sound' }),
      h('button.chip', { type: 'button', 'aria-pressed': db.settings.restVibrate ? 'true' : 'false', onClick: () => { app.store.commit((d) => { d.settings.restVibrate = !d.settings.restVibrate; }); app.render(); }, text: 'Vibrate' })),
      'Sound and vibration only work where the browser allows them. When the app is in the background or the phone is locked, browser alerts may not fire — the timer itself stays accurate because it runs on timestamps.'));
    stack.appendChild(rest);

    /* Effort */
    stack.appendChild(h('div.card', h('h3', { text: 'Effort' }), h('p.small', { style: { marginTop: '6px' }, text: P.EFFORT_GUIDANCE.short }), h('p.small.muted', { style: { marginTop: '6px' }, text: P.EFFORT_GUIDANCE.rir }), h('p.small.muted', { style: { marginTop: '6px' }, text: P.EFFORT_GUIDANCE.warmup })));

    /* Appearance */
    const app2 = h('div.card.stack');
    app2.appendChild(h('h3', { text: 'Appearance' }));
    app2.appendChild(field('Theme', chips([['auto', 'System'], ['light', 'Light'], ['dark', 'Dark']], db.settings.theme, (v) => { app.store.commit((d) => { d.settings.theme = v; }); app.applyTheme(); app.render(); })));
    stack.appendChild(app2);

    /* Storage */
    const stor = h('div.card.stack');
    stor.appendChild(h('h3', { text: 'Where your data lives' }));
    stor.appendChild(h('p.small', { text: app.store.backend.label + '.' }));
    stor.appendChild(h('p.small.muted', { text: app.storageNote() }));
    stor.appendChild(h('p.small.muted', { text: 'Export and import (JSON and CSV) arrive with the export slice. Until then there is no backup — treat this as a working copy.' }));
    stack.appendChild(stor);

    /* Data */
    const data = h('div.card.stack');
    data.appendChild(h('h3', { text: 'Data' }));
    const n = db.sessionOrder.length, m = db.measurements.length;
    data.appendChild(h('p.small.muted', { text: n + ' session' + (n === 1 ? '' : 's') + ', ' + m + ' measurement' + (m === 1 ? '' : 's') + ' on this device.' }));
    data.appendChild(h('button.btn.danger', { onClick: async () => {
      const ok = await X.confirm({ title: 'Delete all data?', body: 'Every session, set, measurement and setting on this device is removed. There is no undo and no backup yet.', confirmLabel: 'Delete everything', danger: true, typed: 'DELETE' });
      if (!ok) return;
      await app.resetAll();
    }, text: 'Delete all data on this device' }));
    stack.appendChild(data);

    root.appendChild(stack);
  };

  function field(label, control, help) {
    const f = h('div.field', h('label', { text: label }), control);
    if (help) f.appendChild(h('p.help', { text: help }));
    return f;
  }
  function chips(options, current, onPick) {
    const wrap = h('div.chips');
    options.forEach(([v, label]) => wrap.appendChild(h('button.chip', { type: 'button', 'aria-pressed': current === v ? 'true' : 'false', onClick: () => onPick(v), text: label })));
    return wrap;
  }

  CS.profile = PF;
})();

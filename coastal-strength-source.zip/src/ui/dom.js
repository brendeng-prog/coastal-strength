/* Coastal Strength — ui/dom.js */
(function () {
  const CS = (window.CS = window.CS || {});
  const U = CS.util;
  const X = {};

  /* h('div.card.stack', { onClick }, child, [children], 'text') */
  X.h = function (spec, attrs) {
    const parts = spec.split('.');
    const el = document.createElement(parts[0] || 'div');
    if (parts.length > 1) el.className = parts.slice(1).join(' ');
    if (attrs && typeof attrs === 'object' && !(attrs instanceof Node) && !Array.isArray(attrs)) {
      Object.keys(attrs).forEach((k) => {
        const v = attrs[k];
        if (v == null || v === false) return;
        if (k === 'class') el.className += (el.className ? ' ' : '') + v;
        else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
        else if (k === 'html') el.innerHTML = v;
        else if (k === 'text') el.textContent = v;
        else if (k.slice(0, 2) === 'on' && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
        else if (k === 'value' || k === 'checked' || k === 'disabled' || k === 'readOnly' || k === 'selected') el[k] = v;
        else el.setAttribute(k, v === true ? '' : v);
      });
    } else if (attrs != null) {
      X.append(el, attrs);
    }
    for (let i = 2; i < arguments.length; i++) X.append(el, arguments[i]);
    return el;
  };

  X.append = function (el, child) {
    if (child == null || child === false) return;
    if (Array.isArray(child)) { child.forEach((c) => X.append(el, c)); return; }
    if (child instanceof Node) { el.appendChild(child); return; }
    el.appendChild(document.createTextNode(String(child)));
  };

  X.clear = function (el) { while (el.firstChild) el.removeChild(el.firstChild); return el; };

  X.svg = function (html, cls) {
    const wrap = document.createElement('span');
    wrap.innerHTML = html;
    const s = wrap.firstElementChild;
    if (cls) s.setAttribute('class', cls);
    return s;
  };

  X.ICON = {
    check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7"/></svg>',
    more: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><circle cx="5" cy="12" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="19" cy="12" r="2"/></svg>',
    today: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="3"/><path d="M3 10h18M8 3v4M16 3v4"/></svg>',
    train: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><path d="M3 12h2M19 12h2M6 8v8M18 8v8M9 6v12M15 6v12M9 12h6"/></svg>',
    progress: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 19V5M4 19h16M7 15l4-5 3 3 5-7"/></svg>',
    nutrition: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><path d="M6 3v7a3 3 0 0 0 6 0V3M9 3v18M16 3c-2 2-2 6 0 8v10"/></svg>',
    profile: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4 21c1-4 4-6 8-6s7 2 8 6"/></svg>',
    pause: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><rect x="6" y="5" width="4" height="14" rx="1"/><rect x="14" y="5" width="4" height="14" rx="1"/></svg>',
    play: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M7 5v14l12-7z"/></svg>',
    close: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>'
  };

  /* Bottom sheet. Returns { close }. */
  X.sheet = function (title, build) {
    const back = X.h('div.sheet-back', { role: 'dialog', 'aria-modal': 'true', 'aria-label': title || 'Options' });
    const sh = X.h('div.sheet');
    const api = { close() { if (back.parentNode) back.parentNode.removeChild(back); document.removeEventListener('keydown', onKey); } };
    function onKey(e) { if (e.key === 'Escape') api.close(); }
    back.addEventListener('click', (e) => { if (e.target === back) api.close(); });
    document.addEventListener('keydown', onKey);
    if (title) sh.appendChild(X.h('h2', { text: title }));
    build(sh, api);
    back.appendChild(sh);
    document.body.appendChild(back);
    const first = sh.querySelector('button, input, select, textarea');
    if (first) setTimeout(() => first.focus(), 30);
    return api;
  };

  /* Action list sheet: items = [{label, onSelect, danger, hint}] */
  X.actionSheet = function (title, items) {
    return X.sheet(title, (sh, api) => {
      const list = X.h('div.list');
      items.filter(Boolean).forEach((it) => {
        list.appendChild(X.h('button', { class: it.danger ? 'danger' : '', onClick: () => { api.close(); it.onSelect(); } },
          X.h('span', { text: it.label }), it.hint ? X.h('span.small.muted', { text: it.hint }) : null));
      });
      sh.appendChild(list);
      sh.appendChild(X.h('button.btn.block', { style: { marginTop: '10px' }, onClick: api.close, text: 'Cancel' }));
    });
  };

  /* Confirm sheet. opts: { title, body, confirmLabel, danger, typed } -> Promise<boolean> */
  X.confirm = function (opts) {
    return new Promise((resolve) => {
      X.sheet(opts.title, (sh, api) => {
        if (opts.body) sh.appendChild(X.h('p.muted', { text: opts.body, style: { marginBottom: '14px' } }));
        let typedOk = !opts.typed;
        let btn;
        if (opts.typed) {
          const inp = X.h('input.input', { type: 'text', placeholder: 'Type ' + opts.typed + ' to confirm', autocomplete: 'off', 'aria-label': 'Type ' + opts.typed + ' to confirm' });
          inp.addEventListener('input', () => { typedOk = inp.value.trim().toUpperCase() === opts.typed.toUpperCase(); btn.disabled = !typedOk; });
          sh.appendChild(X.h('div.field', { style: { marginBottom: '12px' } }, inp));
        }
        btn = X.h('button.btn.block', { class: opts.danger ? 'danger solid' : 'primary', disabled: !typedOk, onClick: () => { api.close(); resolve(true); }, text: opts.confirmLabel || 'Confirm' });
        sh.appendChild(btn);
        sh.appendChild(X.h('button.btn.block', { style: { marginTop: '8px' }, onClick: () => { api.close(); resolve(false); }, text: opts.cancelLabel || 'Cancel' }));
      });
    });
  };

  /* Prompt sheet -> Promise<string|null> */
  X.prompt = function (opts) {
    return new Promise((resolve) => {
      X.sheet(opts.title, (sh, api) => {
        const inp = X.h(opts.multiline ? 'textarea.input' : 'input.input', { type: opts.type || 'text', value: opts.value || '', placeholder: opts.placeholder || '', inputmode: opts.inputmode, 'aria-label': opts.title });
        if (opts.help) sh.appendChild(X.h('p.help', { text: opts.help, style: { marginBottom: '10px' } }));
        sh.appendChild(X.h('div.field', { style: { marginBottom: '12px' } }, inp));
        sh.appendChild(X.h('button.btn.block.primary', { onClick: () => { api.close(); resolve(inp.value); }, text: opts.confirmLabel || 'Save' }));
        sh.appendChild(X.h('button.btn.block', { style: { marginTop: '8px' }, onClick: () => { api.close(); resolve(null); }, text: 'Cancel' }));
      });
    });
  };

  let toastTimer = null;
  X.toast = function (msg, ms) {
    const old = document.querySelector('.toast');
    if (old) old.remove();
    const t = X.h('div.toast', { role: 'status', text: msg });
    document.body.appendChild(t);
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.remove(), ms || 2200);
  };

  /* Numeric input bound to a setter. opts: { value, integer, max, placeholder, cls, label, onValue(value|null), inputmode } */
  X.numInput = function (opts) {
    const inp = X.h('input', {
      class: opts.cls || 'input', type: 'text', inputmode: opts.inputmode || (opts.integer ? 'numeric' : 'decimal'),
      pattern: opts.integer ? '[0-9]*' : '[0-9]*[.,]?[0-9]*', autocomplete: 'off', enterkeyhint: 'done',
      placeholder: opts.placeholder || '', 'aria-label': opts.label || '', value: opts.value == null ? '' : String(opts.value)
    });
    inp.addEventListener('focus', () => { try { inp.select(); } catch (e) { /* ignore */ } setTimeout(() => { try { inp.scrollIntoView({ block: 'center', behavior: 'smooth' }); } catch (e) { /* ignore */ } }, 250); });
    inp.addEventListener('input', () => {
      const r = U.parseNum(inp.value, { integer: opts.integer, max: opts.max });
      inp.classList.toggle('invalid', !!r.error);
      inp.classList.remove('prefilled');
      if (r.error) { inp.setAttribute('aria-invalid', 'true'); inp.title = r.error; if (opts.onError) opts.onError(r.error); return; }
      inp.removeAttribute('aria-invalid'); inp.title = '';
      if (opts.onError) opts.onError(null);
      opts.onValue(r.value);
    });
    inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') inp.blur(); });
    return inp;
  };

  /* Plate math: plates per side for a target total on a bar. */
  X.plateMath = function (target, bar, plates) {
    if (target == null || target < bar) return { perSide: [], remainder: target == null ? null : target - bar, exact: false };
    let perSide = (target - bar) / 2;
    const out = [];
    plates.slice().sort((a, b) => b - a).forEach((p) => {
      while (perSide + 1e-9 >= p) { out.push(p); perSide -= p; }
    });
    return { perSide: out, remainder: Math.round(perSide * 100) / 100, exact: Math.abs(perSide) < 1e-6 };
  };

  X.PLATES = { lb: [45, 35, 25, 10, 5, 2.5], kg: [25, 20, 15, 10, 5, 2.5, 1.25] };
  X.BARS = { lb: [45, 35, 15], kg: [20, 15, 10] };

  CS.dom = X;
})();

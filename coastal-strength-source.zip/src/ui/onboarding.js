/* Coastal Strength — ui/onboarding.js */
(function () {
  const CS = (window.CS = window.CS || {});
  const X = CS.dom, U = CS.util, P = CS.plan, B = CS.brand;
  const h = X.h;
  const O = {};

  const LAST_REPORTED_WEIGHT = 172; // lb — confirm or correct; never assumed

  O.render = function (root, onDone) {
    const tz = U.defaultTz();
    const st = {
      step: 0,
      name: 'Brenden', units: 'lb', timezone: tz,
      weight: LAST_REPORTED_WEIGHT, weightTouched: false, weightDate: U.localDate(Date.now(), tz),
      heightFt: 6, heightIn: 1, heightCm: 185,
      schedule: Object.assign({}, P.DEFAULT_SCHEDULE),
      equipment: { barbell: true, dumbbells: true, cables: true, machines: true, pullup_bar: true },
      picks: {},
      nutritionMode: 'undecided', calorieTarget: null,
      experience: '', limitations: '',
      errors: {}
    };
    P.OR_SLOTS.forEach((s) => { st.picks[s.slotId] = s.options[0]; });

    const steps = [stepYou, stepSchedule, stepGear, stepNutrition, stepGoal];

    function draw() {
      X.clear(root);
      const scr = h('div.screen.no-tabs.ob');
      scr.appendChild(h('div.topbar', h('div.brand', B.mark(26), h('span', { text: 'Coastal Strength' }))));
      scr.appendChild(h('div.step', { text: 'Step ' + (st.step + 1) + ' of ' + steps.length }));
      steps[st.step](scr);
      root.appendChild(scr);
      window.scrollTo(0, 0);
    }

    function actions(scr, opts) {
      opts = opts || {};
      const bar = h('div.actions');
      if (st.step > 0) bar.appendChild(h('button.btn', { onClick: () => { st.step--; draw(); }, text: 'Back' }));
      if (opts.skippable) bar.appendChild(h('button.btn', { onClick: () => next(true), text: 'Skip' }));
      bar.appendChild(h('button.btn.primary', { onClick: () => next(false), text: opts.label || 'Continue' }));
      scr.appendChild(bar);
    }

    function next(skipped) {
      if (!skipped && steps[st.step].validate && !steps[st.step].validate()) { draw(); return; }
      if (st.step === steps.length - 1) { finish(); return; }
      st.step++; draw();
    }

    function finish() {
      const heightIn = st.units === 'lb' ? st.heightFt * 12 + st.heightIn : st.heightCm / 2.54;
      onDone({
        name: st.name.trim(), units: st.units, timezone: st.timezone,
        weight: st.weight, weightUnit: st.units, weightDate: st.weightDate,
        heightIn: heightIn ? Math.round(heightIn * 10) / 10 : null,
        schedule: st.schedule, equipment: st.equipment, picks: st.picks,
        nutritionMode: st.nutritionMode, calorieTarget: st.calorieTarget,
        experience: st.experience, limitations: st.limitations,
        frameNoteShown: true
      });
    }

    /* Step 1: you */
    function stepYou(scr) {
      scr.appendChild(h('h1', { text: 'Start with the basics' }));
      scr.appendChild(h('p.lead', { text: 'Everything here is editable later in Profile.' }));
      const stack = h('div.stack');
      stack.appendChild(field('Name', h('input.input', { type: 'text', value: st.name, autocomplete: 'given-name', 'aria-label': 'Name', onInput: (e) => { st.name = e.target.value; } })));
      stack.appendChild(field('Units', chips([['lb', 'lb / ft-in'], ['kg', 'kg / cm']], st.units, (v) => { st.units = v; if (st.weight != null) { st.weight = v === 'kg' ? Math.round(U.toUnit(st.weight, 'lb', 'kg') * 10) / 10 : Math.round(U.toUnit(st.weight, 'kg', 'lb') * 10) / 10; } draw(); })));

      const lastW = st.units === 'lb' ? LAST_REPORTED_WEIGHT : Math.round(U.toUnit(LAST_REPORTED_WEIGHT, 'lb', 'kg') * 10) / 10;
      const wInput = X.numInput({ value: st.weight, placeholder: String(lastW), label: 'Current weight in ' + st.units, onValue: (v) => { st.weight = v; st.weightTouched = true; const b = root.querySelector('.ob .actions .btn.primary'); if (b) b.textContent = 'Continue'; } });
      const wField = field('Current weight (' + st.units + ')', h('div.row', wInput, h('span.muted', { text: st.units })), st.errors.weight);
      wField.appendChild(h('p.help', { text: 'Last reported: ' + lastW + ' ' + st.units + '. Confirm it below or type the correct number.' }));
      stack.appendChild(wField);
      stack.appendChild(field('Weighed on', h('input.input', { type: 'date', value: st.weightDate, 'aria-label': 'Weight measurement date', max: U.localDate(Date.now(), st.timezone), onInput: (e) => { st.weightDate = e.target.value; } })));

      if (st.units === 'lb') {
        stack.appendChild(field('Height', h('div.row',
          X.numInput({ value: st.heightFt, integer: true, max: 8, label: 'Height feet', onValue: (v) => { st.heightFt = v || 0; } }), h('span.muted', { text: 'ft' }),
          X.numInput({ value: st.heightIn, integer: true, max: 11, label: 'Height inches', onValue: (v) => { st.heightIn = v || 0; } }), h('span.muted', { text: 'in' }))));
      } else {
        stack.appendChild(field('Height (cm)', X.numInput({ value: st.heightCm, max: 260, label: 'Height in centimetres', onValue: (v) => { st.heightCm = v || 0; } })));
      }

      const tzSel = h('select.input', { 'aria-label': 'Time zone', onChange: (e) => { st.timezone = e.target.value; } });
      let zones = [];
      try { zones = Intl.supportedValuesOf('timeZone'); } catch (e) { zones = [st.timezone]; }
      if (zones.indexOf(st.timezone) < 0) zones.unshift(st.timezone);
      zones.forEach((z) => tzSel.appendChild(h('option', { value: z, selected: z === st.timezone, text: z })));
      stack.appendChild(field('Time zone', tzSel, null, 'Used for the day boundary on schedules and daily logs.'));
      scr.appendChild(stack);
      actions(scr, { label: st.weightTouched || st.weight !== lastW ? 'Continue' : 'Confirm ' + lastW + ' ' + st.units });
    }
    stepYou.validate = function () {
      st.errors = {};
      if (st.weight == null || st.weight <= 0) st.errors.weight = 'Enter your current weight.';
      if (!U.isLocalDate(st.weightDate)) st.errors.weight = 'Enter the date you weighed in.';
      return !Object.keys(st.errors).length;
    };

    /* Step 2: schedule */
    function stepSchedule(scr) {
      scr.appendChild(h('h1', { text: 'Training days' }));
      scr.appendChild(h('p.lead', { text: 'The default week from your plan. Move a session to another weekday if it fits better; unassigned days are rest.' }));
      const stack = h('div.stack');
      const plan = P.DEFAULT_TEMPLATES;
      ['push', 'pull', 'legs', 'upper', 'zone2', 'conditioning'].forEach((tid) => {
        const sel = h('select.input', { 'aria-label': plan[tid].name + ' day', onChange: (e) => { st.schedule[tid] = e.target.value || null; draw(); } });
        sel.appendChild(h('option', { value: '', selected: !st.schedule[tid], text: 'Not scheduled' }));
        U.WEEKDAYS.forEach((wd) => sel.appendChild(h('option', { value: wd, selected: st.schedule[tid] === wd, text: U.WEEKDAY_LABEL[wd] })));
        stack.appendChild(field(plan[tid].name + (plan[tid].kind === 'lift' ? '' : ' (' + (plan[tid].kind === 'cardio_optional' ? 'optional cardio' : 'cardio + abs') + ')'), sel));
      });
      if (st.errors.schedule) stack.appendChild(h('p.error', { text: st.errors.schedule }));
      scr.appendChild(stack);
      actions(scr);
    }
    stepSchedule.validate = function () {
      st.errors = {};
      const used = {};
      for (const t in st.schedule) {
        const wd = st.schedule[t];
        if (!wd) continue;
        if (used[wd]) { st.errors.schedule = 'Two sessions are on ' + U.WEEKDAY_LABEL[wd] + '. One session per day.'; return false; }
        used[wd] = true;
      }
      return true;
    };

    /* Step 3: gear + picks */
    function stepGear(scr) {
      scr.appendChild(h('h1', { text: 'Your gym' }));
      scr.appendChild(h('p.lead', { text: 'Pick the option you\'ll use for each "or" in the plan. Skip if you\'d rather decide on the day.' }));
      const stack = h('div.stack');
      const eq = h('div.chips');
      P.EQUIPMENT.forEach((e) => eq.appendChild(h('button.chip', { type: 'button', 'aria-pressed': st.equipment[e.id] ? 'true' : 'false', onClick: () => { st.equipment[e.id] = !st.equipment[e.id]; draw(); }, text: e.label })));
      stack.appendChild(field('Equipment available', eq));
      P.OR_SLOTS.forEach((s) => {
        stack.appendChild(field(s.label, chips(s.options.map((id) => [id, P.EXERCISE_MAP[id].name]), st.picks[s.slotId], (v) => { st.picks[s.slotId] = v; draw(); })));
      });
      scr.appendChild(stack);
      actions(scr, { skippable: true });
    }

    /* Step 4: nutrition mode + experience */
    function stepNutrition(scr) {
      scr.appendChild(h('h1', { text: 'Nutrition mode' }));
      scr.appendChild(h('p.lead', { text: 'A preference for how the app frames your targets, not a prescription. Nothing here calculates a deficit for you.' }));
      const stack = h('div.stack');
      stack.appendChild(field('Mode', chips([['maintenance', 'Maintenance / recomp'], ['gain', 'Gradual gain'], ['loss', 'Gradual fat loss'], ['undecided', 'Undecided']], st.nutritionMode, (v) => { st.nutritionMode = v; draw(); })));
      stack.appendChild(field('Calorie target (optional)', h('div.row', X.numInput({ value: st.calorieTarget, integer: true, max: 10000, placeholder: 'Leave blank to skip', label: 'Daily calorie target', onValue: (v) => { st.calorieTarget = v; } }), h('span.muted', { text: 'kcal' })), null, 'Only if you already have one. The app never sets or changes this on its own.'));
      stack.appendChild(field('Experience (optional)', chips([['', 'Skip'], ['beginner', 'Under 1 year'], ['intermediate', '1–3 years'], ['advanced', '3+ years']], st.experience, (v) => { st.experience = v; draw(); })));
      stack.appendChild(field('Limitations or injuries (optional)', h('textarea.input', { placeholder: 'e.g. left shoulder — avoid deep dips', 'aria-label': 'Limitations', onInput: (e) => { st.limitations = e.target.value; } }, st.limitations)));
      scr.appendChild(stack);
      actions(scr, { skippable: true });
    }

    /* Step 5: goal framing, stated once */
    function stepGoal(scr) {
      scr.appendChild(h('h1', { text: 'What moves the needle' }));
      scr.appendChild(h('p.lead', { text: 'You\'re training toward a lean, athletic build: broad-reading shoulders, upper chest and upper back, defined arms, visible abs, no bulk. This is a direction, not a promise. In order of leverage, it comes from:' }));
      scr.appendChild(h('ol.leverage',
        h('li', h('b', { text: 'Body fat low enough for abs to show' }), ' — driven by nutrition and time, not by exercise selection.'),
        h('li', h('b', { text: 'Shoulder-to-waist ratio' }), ' — built mainly by side and rear delts.'),
        h('li', h('b', { text: 'Upper chest and upper back thickness.' })),
        h('li', h('b', { text: 'Arm development.' }))));
      scr.appendChild(h('p', { style: { marginTop: '14px' }, text: 'One thing to say once: skeletal frame and proportions are not trainable. Everything above is.' }));
      scr.appendChild(h('div.card', { style: { marginTop: '18px' } },
        h('h3', { text: 'Effort' }),
        h('p.small', { style: { marginTop: '6px' }, text: P.EFFORT_GUIDANCE.short }),
        h('p.small.muted', { style: { marginTop: '6px' }, text: P.EFFORT_GUIDANCE.rir }),
        h('p.small.muted', { style: { marginTop: '6px' }, text: P.EFFORT_GUIDANCE.warmup })));
      scr.appendChild(h('p.small.muted', { style: { marginTop: '14px' }, text: 'Your plan is seeded exactly as written: Push, Pull, Legs & Abs, optional Zone 2, Upper, Conditioning & Abs, Rest. Leg day stays — it\'s for proportion and joint durability.' }));
      actions(scr, { label: 'Go to Today' });
    }

    /* helpers */
    function field(label, control, error, help) {
      const f = h('div.field', h('label', { text: label }), control);
      if (help) f.appendChild(h('p.help', { text: help }));
      if (error) f.appendChild(h('p.error', { role: 'alert', text: error }));
      return f;
    }
    function chips(options, current, onPick) {
      const wrap = h('div.chips');
      options.forEach(([v, label]) => wrap.appendChild(h('button.chip', { type: 'button', 'aria-pressed': current === v ? 'true' : 'false', onClick: () => onPick(v), text: label })));
      return wrap;
    }

    draw();
  };

  CS.onboarding = O;
})();

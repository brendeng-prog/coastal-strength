/* Coastal Strength — ui/today.js */
(function () {
  const CS = (window.CS = window.CS || {});
  const X = CS.dom, U = CS.util, D = CS.db, S = CS.stats, B = CS.brand;
  const h = X.h;
  const T = {};

  T.render = function (root, app) {
    const db = app.store.db;
    const today = app.today();
    const plan = S.todayPlan(db, today);
    const active = D.findActiveSession(db);
    const stack = h('div.stack');

    /* Card 1 — today's session (the one primary action) */
    const t = plan.template;
    const session = plan.session;
    const card = h('div.card.session-card');
    card.appendChild(h('p.small.muted', { text: U.fmtLocalDate(today, { weekday: 'long', month: 'short', day: 'numeric' }) }));
    if (active) {
      const at = active.templateName;
      const c = D.counts(active);
      card.appendChild(h('p.name', { text: at + (active.localDate === today ? '' : ' is still open') }));
      card.appendChild(h('p.small.muted', { text: (active.localDate === today ? '' : 'Started ' + U.fmtLocalDate(active.localDate) + '. ') + c.workingDone + ' of ' + c.workingPrescribed + ' working sets logged' + (active.status === 'paused' ? ' · paused' : '') + '.' + (active.templateId !== t.id && t.kind === 'lift' ? ' Today\'s scheduled session is ' + t.name + '; finish this one first.' : '') }));
      card.appendChild(h('button.btn.primary.block', { style: { marginTop: '14px' }, onClick: () => app.navigate('train', { view: 'logger' }), text: 'Resume workout' }));
    } else if (t.kind === 'rest') {
      card.appendChild(h('p.name', { text: 'Rest day' }));
      card.appendChild(h('p.small.muted', { text: 'Rest is a valid completion. Optional: a walk, mobility work, or a note.' }));
      card.appendChild(h('button.btn.block', { style: { marginTop: '14px' }, onClick: () => app.navigate('train'), text: 'See the week' }));
    } else if (t.kind === 'cardio_optional') {
      card.appendChild(h('p.name', { text: t.name }));
      card.appendChild(h('p.small.muted', { text: 'Optional ' + t.cardio.minutesMin + '–' + t.cardio.minutesMax + ' min at conversational intensity. "Rest" is a valid completion, not a failure.' }));
      card.appendChild(h('p.small.muted', { style: { marginTop: '6px' }, text: 'Cardio logging is not built yet — it arrives with the recovery & cardio slice.' }));
    } else {
      const n = t.slots ? t.slots.length : 0;
      card.appendChild(h('p.name', { text: t.name }));
      const lines = (t.slots || []).map((sl) => {
        const exId = db.profile.picks[sl.slotId] && sl.options.indexOf(db.profile.picks[sl.slotId]) >= 0 ? db.profile.picks[sl.slotId] : sl.options[0];
        return D.exercise(db, exId).name + ' ' + sl.sets + '×' + (sl.timed ? sl.timed.secMin + '–' + sl.timed.secMax + ' s' : sl.repMin + '–' + sl.repMax);
      });
      card.appendChild(h('p.small.muted', { text: n + ' exercises · ' + lines.join(' · ') }));
      if (session && session.status === 'completed') {
        const c = D.counts(session);
        card.appendChild(h('p.small', { style: { marginTop: '10px' }, text: 'Done: ' + c.workingDone + ' working sets in ' + U.fmtDuration(D.activeMs(session, Date.now())) + '.' }));
        card.appendChild(h('button.btn.block', { style: { marginTop: '12px' }, onClick: () => app.navigate('train', { view: 'summary', sessionId: session.id }), text: 'View summary' }));
      } else if (session && (session.status === 'in_progress' || session.status === 'paused')) {
        const c = D.counts(session);
        card.appendChild(h('p.small', { style: { marginTop: '10px' }, text: c.workingDone + ' of ' + c.workingPrescribed + ' working sets logged' + (session.status === 'paused' ? ' · paused' : '') + '.' }));
        card.appendChild(h('button.btn.primary.block', { style: { marginTop: '12px' }, onClick: () => app.navigate('train'), text: 'Resume workout' }));
      } else if (t.kind === 'conditioning') {
        card.appendChild(h('p.small.muted', { style: { marginTop: '6px' }, text: 'The abs circuit logs now; the interval timer and Zone 2 logging arrive with the cardio slice.' }));
        card.appendChild(h('button.btn.primary.block', { style: { marginTop: '12px' }, onClick: () => app.startSession(t.id), text: 'Start workout' }));
      } else {
        card.appendChild(h('button.btn.primary.block', { style: { marginTop: '14px' }, onClick: () => app.startSession(t.id), text: 'Start workout' }));
      }
    }
    stack.appendChild(card);

    /* Card 2 — week ring */
    const ring = S.weekRing(db, today);
    const rc = h('div.card');
    const rr = h('div.ring', B.ring(ring.completed, ring.scheduled),
      h('div', h('div.big', { text: ring.completed + ' of ' + ring.scheduled + ' sessions this week' }), h('div.small.muted', { text: 'Scheduled lifting sessions only. Cardio and rest days are not counted.' })));
    rc.appendChild(rr);
    const dots = h('div.daydots');
    ring.days.forEach((d) => {
      const cls = ['daydot', d.kind === 'lift' ? 'lift' : '', d.status === 'completed' ? 'done' : '', d.isToday ? 'today' : '', d.status === 'other' ? 'other' : ''].filter(Boolean).join(' ');
      dots.appendChild(h('div', { class: cls, title: d.templateName }, h('i'), h('span', { text: U.WEEKDAY_SHORT[d.key][0] })));
    });
    rc.appendChild(dots);
    stack.appendChild(rc);

    /* Card 3 — weight */
    const w = S.weightSummary(db, today);
    const wc = h('div.card');
    if (w) {
      wc.appendChild(h('div.row.between', h('div', h('div.weightline', { text: U.fmtNum(w.latest.value, 1) + ' ' + w.latest.unit }), h('div.small.muted', { text: 'Weighed ' + U.fmtLocalDate(w.latest.localDate) + (w.avg7 != null ? ' · 7-day average ' + U.fmtNum(w.avg7, 1) + ' ' + w.latest.unit : ' · 7-day average needs 3 weigh-ins in a week (' + w.avg7Count + ' so far)') })),
        h('button.btn.sm', { onClick: () => logWeight(app), text: 'Log weight' })));
    } else {
      wc.appendChild(h('div.row.between', h('div.muted', { text: 'No weight logged yet.' }), h('button.btn.sm', { onClick: () => logWeight(app), text: 'Log weight' })));
    }
    stack.appendChild(wc);

    /* Protein and check-in cards are not built yet — nothing is shown rather than a placeholder with fake numbers. */

    /* Observations (max 2), each from a specific log */
    const obs = S.observations(db, today);
    if (obs.length) {
      const oc = h('div.card.flat');
      obs.forEach((o, i) => {
        const line = h('p.small', { style: i ? { marginTop: '8px' } : null, text: o.text });
        if (o.source) line.appendChild(h('button.link.small', { style: { marginLeft: '6px' }, onClick: () => app.navigate('train', { view: 'summary', sessionId: o.source.sessionId }), text: 'See session' }));
        oc.appendChild(line);
      });
      stack.appendChild(oc);
    }

    root.appendChild(stack);
  };

  function logWeight(app) {
    const db = app.store.db;
    X.sheet('Log weight', (sh, api) => {
      let value = null, date = app.today(), err = null;
      const inp = X.numInput({ placeholder: 'e.g. 172', max: 1000, label: 'Weight in ' + db.profile.units, onValue: (v) => { value = v; }, onError: (e) => { err = e; } });
      inp.classList.add('setinput');
      const dateInp = h('input.input', { type: 'date', value: date, max: app.today(), 'aria-label': 'Date', onInput: (e) => { date = e.target.value; } });
      sh.appendChild(h('div.stack', h('div.field', h('label', { text: 'Weight (' + db.profile.units + ')' }), inp), h('div.field', h('label', { text: 'Date' }), dateInp)));
      sh.appendChild(h('button.btn.block.primary', { style: { marginTop: '14px' }, onClick: () => {
        if (err || value == null || value <= 0) { X.toast('Enter a weight above 0.'); return; }
        if (!U.isLocalDate(date)) { X.toast('Pick a date.'); return; }
        app.store.commit((d) => D.addMeasurement(d, { type: 'weight', value, unit: d.profile.units, localDate: date }, new Date().toISOString()));
        api.close(); X.toast('Weight logged');
      }, text: 'Save' }));
      sh.appendChild(h('button.btn.block', { style: { marginTop: '8px' }, onClick: api.close, text: 'Cancel' }));
    });
  }

  CS.today = T;
})();

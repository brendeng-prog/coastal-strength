/* Coastal Strength — ui/brand.js */
(function () {
  const CS = (window.CS = window.CS || {});
  const X = CS.dom;
  const B = {};

  B.MARK_PATH = 'M37 27.5 C46 27 52 18.5 45.5 12 C36 5 17.5 9 13.5 24 C9.5 40 18 54 34 55 C43 55.6 50.5 50 55 41';

  B.mark = function (size, color) {
    return X.svg('<svg viewBox="0 0 64 64" width="' + (size || 24) + '" height="' + (size || 24) + '" aria-hidden="true"><path d="' + B.MARK_PATH + '" fill="none" stroke="' + (color || 'var(--accent)') + '" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/></svg>');
  };

  /* Week ring: completed / scheduled. Accent only when something is earned. */
  B.ring = function (completed, scheduled, size) {
    const r = 28, c = 2 * Math.PI * r;
    const frac = scheduled > 0 ? completed / scheduled : 0;
    const dash = (c * frac).toFixed(2) + ' ' + (c * (1 - frac)).toFixed(2);
    return X.svg(
      '<svg viewBox="0 0 72 72" width="' + (size || 72) + '" height="' + (size || 72) + '" role="img" aria-label="' + completed + ' of ' + scheduled + ' scheduled lifting sessions completed this week">' +
      '<circle cx="36" cy="36" r="' + r + '" fill="none" stroke="var(--line)" stroke-width="7"/>' +
      (completed > 0 ? '<circle cx="36" cy="36" r="' + r + '" fill="none" stroke="var(--accent)" stroke-width="7" stroke-linecap="round" stroke-dasharray="' + dash + '" transform="rotate(-90 36 36)"/>' : '') +
      '<text x="36" y="41" text-anchor="middle" font-size="16" font-weight="600" fill="currentColor">' + completed + '/' + scheduled + '</text></svg>');
  };

  /* Rep-range bar: where a set sits inside [repMin, repMax]. */
  B.rangeBar = function (reps, repMin, repMax) {
    const wrap = X.h('div.rangebar', { role: 'img', 'aria-label': reps == null ? 'No reps logged' : reps + ' reps in a ' + repMin + ' to ' + repMax + ' range' });
    const span = Math.max(1, repMax - repMin);
    if (reps != null) {
      const frac = Math.max(0, Math.min(1, (reps - repMin + 1) / (span + 1)));
      wrap.appendChild(X.h('div.fill', { style: { width: (frac * 100).toFixed(1) + '%' } }));
    }
    return wrap;
  };

  CS.brand = B;
})();

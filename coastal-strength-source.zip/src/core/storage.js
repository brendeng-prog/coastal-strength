/* Coastal Strength — core/storage.js
   Local-first persistence. The whole database is one JSON document written atomically,
   so a retried write can never duplicate a set or a session.

   Backends, tried in order:
     1. window.storage  — the claude.ai preview's per-user key-value API (artifact sandbox)
     2. IndexedDB       — when hosted as a normal web page / iPhone home-screen app
     3. localStorage    — fallback
     4. memory          — nothing persists; the UI shows a warning
   None of these is cloud sync. Data lives on this device in this browser. */
(function () {
  const CS = (window.CS = window.CS || {});
  const KEY = 'cs:db';
  const ST = {};

  function previewBackend() {
    const w = window.storage;
    if (!w || typeof w.get !== 'function' || typeof w.set !== 'function') return null;
    return {
      mode: 'preview',
      label: 'Preview storage (claude.ai account, this artifact)',
      async probe() {
        const r = await w.set('cs:probe', '1', false);
        if (!r) throw new Error('preview storage set failed');
        try { await w.delete('cs:probe', false); } catch (e) { /* ignore */ }
        return true;
      },
      async load() {
        try {
          const r = await w.get(KEY, false);
          return r && r.value ? r.value : null;
        } catch (e) { return null; } // missing key throws
      },
      async save(json) {
        const r = await w.set(KEY, json, false);
        if (!r) throw new Error('Save rejected by preview storage');
      },
      async clear() { try { await w.delete(KEY, false); } catch (e) { /* ignore */ } }
    };
  }

  function idbBackend() {
    if (typeof indexedDB === 'undefined' || !indexedDB) return null;
    let dbp = null;
    function open() {
      if (dbp) return dbp;
      dbp = new Promise((resolve, reject) => {
        let req;
        try { req = indexedDB.open('coastal-strength', 1); } catch (e) { reject(e); return; }
        req.onupgradeneeded = () => { req.result.createObjectStore('kv'); };
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error || new Error('IndexedDB open failed'));
        req.onblocked = () => reject(new Error('IndexedDB blocked'));
      });
      return dbp;
    }
    function tx(mode, fn) {
      return open().then((db) => new Promise((resolve, reject) => {
        const t = db.transaction('kv', mode);
        const store = t.objectStore('kv');
        const req = fn(store);
        t.oncomplete = () => resolve(req ? req.result : undefined);
        t.onerror = () => reject(t.error || new Error('IndexedDB transaction failed'));
        t.onabort = () => reject(t.error || new Error('IndexedDB transaction aborted'));
      }));
    }
    return {
      mode: 'indexeddb',
      label: 'IndexedDB (this browser on this device)',
      async probe() { await tx('readonly', (s) => s.get('probe')); return true; },
      async load() { const v = await tx('readonly', (s) => s.get(KEY)); return v == null ? null : v; },
      async save(json) { await tx('readwrite', (s) => s.put(json, KEY)); },
      async clear() { await tx('readwrite', (s) => s.delete(KEY)); }
    };
  }

  function localBackend() {
    try {
      const ls = window.localStorage;
      if (!ls) return null;
      ls.setItem('cs:probe', '1'); ls.removeItem('cs:probe');
      return {
        mode: 'localstorage',
        label: 'localStorage (this browser on this device)',
        sync: true,
        async probe() { return true; },
        async load() { return ls.getItem(KEY); },
        async save(json) { ls.setItem(KEY, json); },
        saveSync(json) { ls.setItem(KEY, json); },
        async clear() { ls.removeItem(KEY); }
      };
    } catch (e) { return null; }
  }

  function memoryBackend() {
    let mem = null;
    return {
      mode: 'memory',
      label: 'Memory only — nothing is saved',
      async probe() { return true; },
      async load() { return mem; },
      async save(json) { mem = json; },
      async clear() { mem = null; }
    };
  }

  /* Pick the first backend that works. */
  ST.detect = async function (prefer) {
    const candidates = [previewBackend, idbBackend, localBackend, memoryBackend];
    for (const make of candidates) {
      const b = make();
      if (!b) continue;
      if (prefer && b.mode !== prefer && b.mode !== 'memory') continue;
      try {
        await Promise.race([b.probe(), new Promise((_, rej) => setTimeout(() => rej(new Error('probe timeout')), 1500))]);
        return b;
      } catch (e) { /* next */ }
    }
    return memoryBackend();
  };

  /* The store: in-memory db + listeners + debounced, serialized autosave. */
  ST.createStore = function (backend, opts) {
    opts = opts || {};
    const debounceMs = opts.debounceMs == null ? 250 : opts.debounceMs;
    const listeners = [];
    const statusListeners = [];
    let db = null;
    let status = { state: 'idle', at: null, message: '' };
    let timer = null, saving = false, dirtyAgain = false, retryTimer = null;

    function setStatus(s) { status = Object.assign({ at: Date.now() }, s); statusListeners.forEach((f) => f(status)); }

    const store = {
      backend,
      get db() { return db; },
      get status() { return status; },
      onChange(f) { listeners.push(f); return () => { const i = listeners.indexOf(f); if (i >= 0) listeners.splice(i, 1); }; },
      onStatus(f) { statusListeners.push(f); return () => { const i = statusListeners.indexOf(f); if (i >= 0) statusListeners.splice(i, 1); }; },

      async load() {
        const json = await backend.load();
        if (!json) { db = null; return null; }
        try {
          const parsed = JSON.parse(json);
          db = CS.db.migrate(parsed);
        } catch (e) {
          setStatus({ state: 'error', message: 'Stored data could not be read: ' + e.message });
          db = null;
        }
        return db;
      },

      /* Replace the db wholesale (onboarding, import). */
      set(next) { db = next; listeners.forEach((f) => f(db)); store.scheduleSave(); },

      /* Apply a mutation and autosave. Every UI write goes through here. */
      commit(fn, opts) {
        if (!db) return undefined;
        const r = fn(db);
        if (!(opts && opts.silent)) listeners.forEach((f) => f(db));
        store.scheduleSave();
        return r;
      },

      scheduleSave() {
        setStatus({ state: 'dirty', message: 'Unsaved changes' });
        if (timer) clearTimeout(timer);
        timer = setTimeout(() => { timer = null; store.flush(); }, debounceMs);
      },

      /* Serialized: one write at a time; a change during a write triggers one more write after it. */
      async flush() {
        if (!db) return;
        if (saving) { dirtyAgain = true; return; }
        if (timer) { clearTimeout(timer); timer = null; }
        saving = true;
        setStatus({ state: 'saving', message: 'Saving…' });
        try {
          db.savedAt = new Date().toISOString();
          await backend.save(JSON.stringify(db));
          setStatus({ state: 'saved', message: backend.mode === 'memory' ? 'Not saved — storage unavailable' : 'Saved' });
        } catch (e) {
          setStatus({ state: 'error', message: 'Save failed — retrying' });
          if (retryTimer) clearTimeout(retryTimer);
          retryTimer = setTimeout(() => { retryTimer = null; dirtyAgain = true; store.flush(); }, 2000);
        } finally {
          saving = false;
          if (dirtyAgain) { dirtyAgain = false; store.flush(); }
        }
      },

      /* Best-effort synchronous write for pagehide on backends that support it. */
      flushSync() {
        if (!db) return;
        if (backend.saveSync) { try { db.savedAt = new Date().toISOString(); backend.saveSync(JSON.stringify(db)); setStatus({ state: 'saved', message: 'Saved' }); } catch (e) { /* ignore */ } }
        else store.flush();
      },

      async clear() { db = null; if (timer) clearTimeout(timer); await backend.clear(); setStatus({ state: 'idle', message: '' }); }
    };
    return store;
  };

  CS.storage = ST;
})();

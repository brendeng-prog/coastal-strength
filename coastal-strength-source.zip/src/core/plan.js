/* Coastal Strength — core/plan.js
   Exercise catalogue + default plan template (spec §6, seeded exactly). */
(function () {
  const CS = (window.CS = window.CS || {});

  /* Exercise types and load conventions — modelled explicitly, never flattened.
     type:           dumbbell | barbell | machine | cable | bodyweight | assisted | weighted_bw | timed
     loadConvention: per_dumbbell | total_bar | machine_stack | none | assistance | added
     Increments are per exercise and per unit; editable later in Profile (not yet built). */
  function ex(id, name, type, opts) {
    const conv = {
      dumbbell: 'per_dumbbell', barbell: 'total_bar', machine: 'machine_stack', cable: 'machine_stack',
      bodyweight: 'none', assisted: 'assistance', weighted_bw: 'added', timed: 'none'
    }[type];
    return Object.assign({
      id, name, type, loadConvention: conv,
      unilateral: false, compound: false, priority: false,
      incrementLb: type === 'dumbbell' ? 5 : type === 'barbell' ? 5 : 5,
      incrementKg: 2.5,
      cues: '',
      family: null // shared substitution family
    }, opts || {});
  }

  const EXERCISES = [
    // Push
    ex('inc_db_press', 'Incline dumbbell press', 'dumbbell', { compound: true, priority: true, family: 'press_incline', cues: 'Bench 30°. Dumbbells start at chest level, press up and slightly in.' }),
    ex('flat_mach_press', 'Flat machine press', 'machine', { compound: true, family: 'press_flat', cues: 'Handles at mid-chest. Full range, no lockout slam.' }),
    ex('flat_db_press', 'Flat dumbbell press', 'dumbbell', { compound: true, family: 'press_flat' }),
    ex('seated_db_ohp', 'Seated dumbbell shoulder press', 'dumbbell', { compound: true, family: 'ohp', cues: 'Back supported. Press to lockout, control down to ear level.' }),
    ex('cable_lat_raise', 'Cable lateral raises', 'cable', { priority: true, unilateral: true, family: 'lat_raise', incrementLb: 2.5, incrementKg: 1, cues: 'Lead with the elbow. Stop at shoulder height.' }),
    ex('rope_pushdown', 'Rope triceps pushdowns', 'cable', { family: 'pushdown', cues: 'Elbows pinned. Spread the rope at the bottom.' }),
    ex('oh_cable_ext', 'Overhead cable extensions', 'cable', { family: 'oh_ext', cues: 'Full stretch at the bottom, elbows stay forward.' }),
    // Pull
    ex('pullup', 'Pull-ups', 'bodyweight', { compound: true, priority: true, family: 'vertical_pull', cues: 'Dead hang start. Chest to bar, control the descent.' }),
    ex('assisted_pullup', 'Assisted pull-ups', 'assisted', { compound: true, priority: true, family: 'vertical_pull', incrementLb: 5, incrementKg: 2.5, cues: 'Load shown is assistance. Less assistance is progress.' }),
    ex('weighted_pullup', 'Weighted pull-ups', 'weighted_bw', { compound: true, priority: true, family: 'vertical_pull', incrementLb: 2.5, incrementKg: 1.25, cues: 'Load shown is added weight (belt or vest).' }),
    ex('cs_row', 'Chest-supported rows', 'machine', { compound: true, priority: true, family: 'row', cues: 'Chest stays on the pad. Drive elbows back and down.' }),
    ex('ng_pulldown', 'Neutral-grip lat pulldowns', 'cable', { compound: true, priority: true, family: 'vertical_pull_machine', cues: 'Lean back slightly. Pull to the upper chest.' }),
    ex('rear_delt_fly', 'Rear-delt flyes', 'machine', { priority: true, family: 'rear_delt', incrementLb: 5, incrementKg: 2.5, cues: 'Reverse pec deck. Arms slightly bent, squeeze at the back.' }),
    ex('rear_delt_fly_db', 'Rear-delt flyes (dumbbell)', 'dumbbell', { priority: true, family: 'rear_delt', incrementLb: 2.5, incrementKg: 1 }),
    ex('inc_db_curl', 'Incline dumbbell curls', 'dumbbell', { priority: true, family: 'curl', incrementLb: 2.5, incrementKg: 1, cues: 'Arms hang behind the torso. Full stretch each rep.' }),
    ex('hammer_curl', 'Hammer curls', 'dumbbell', { priority: true, family: 'curl_neutral', incrementLb: 2.5, incrementKg: 1 }),
    // Legs & Abs
    ex('back_squat', 'Back squats', 'barbell', { compound: true, family: 'squat', cues: 'Brace, sit between the hips, drive up. Stop 1–2 reps short on every set.' }),
    ex('hack_squat', 'Hack squats', 'machine', { compound: true, family: 'squat', incrementLb: 10, incrementKg: 5, cues: 'Feet mid-platform. Full depth you can control.' }),
    ex('rdl', 'Romanian deadlifts', 'barbell', { compound: true, family: 'hinge', cues: 'Hips back, bar stays on the legs, flat back. Stop at hamstring stretch.' }),
    ex('bss', 'Bulgarian split squats', 'dumbbell', { compound: true, unilateral: true, family: 'split_squat', cues: 'Rear foot on bench. Front shin vertical-ish, drive through the whole foot.' }),
    ex('calf_raise', 'Standing calf raises', 'machine', { family: 'calf', incrementLb: 10, incrementKg: 5, cues: 'Pause at the bottom stretch. Full rise.' }),
    ex('hlr', 'Hanging leg raises', 'bodyweight', { family: 'abs_hang', cues: 'Posterior tilt first, then raise. No swing.' }),
    ex('cable_crunch', 'Cable crunches', 'cable', { family: 'abs_cable', cues: 'Round the spine, hips still.' }),
    // Upper
    ex('inc_bb_press', 'Incline barbell press', 'barbell', { compound: true, priority: true, family: 'press_incline', cues: 'Bar to upper chest. Load is total bar weight including the bar.' }),
    ex('lat_pulldown', 'Lat pulldowns', 'cable', { compound: true, priority: true, family: 'vertical_pull_machine', cues: 'Wide-ish grip. Pull to the upper chest, elbows down.' }),
    ex('sa_cable_row', 'Single-arm cable rows', 'cable', { compound: true, priority: true, unilateral: true, family: 'row', cues: 'Rotate slightly as you pull. Full stretch at the front.' }),
    ex('db_lat_raise', 'Dumbbell lateral raises', 'dumbbell', { priority: true, family: 'lat_raise', incrementLb: 2.5, incrementKg: 1, cues: 'Slight forward lean. Raise to shoulder height, lower slow.' }),
    ex('cable_curl', 'Cable curls', 'cable', { family: 'curl', incrementLb: 5, incrementKg: 2.5 }),
    ex('tri_pushdown', 'Triceps pushdowns', 'cable', { family: 'pushdown', cues: 'Straight bar or V-bar. Elbows pinned.' }),
    // Saturday circuit
    ex('ab_wheel', 'Ab-wheel rollouts', 'bodyweight', { family: 'abs_rollout', cues: 'Hips stay level. Roll only as far as you can hold a brace.' }),
    ex('reverse_crunch', 'Reverse crunches', 'bodyweight', { family: 'abs_reverse' }),
    ex('side_plank', 'Side planks', 'timed', { unilateral: true, family: 'abs_side', cues: 'Hips high, straight line head to feet.' })
  ];

  const EXERCISE_MAP = {};
  EXERCISES.forEach((e) => { EXERCISE_MAP[e.id] = e; });

  function slot(slotId, options, sets, repMin, repMax, extra) {
    return Object.assign({ slotId, options, sets, repMin, repMax, perSide: false }, extra || {});
  }

  /* Templates. The user's schedule maps template -> weekday (default below).
     Set counts and rep ranges are verbatim from spec §6. */
  const DEFAULT_TEMPLATES = {
    push: {
      id: 'push', name: 'Push', kind: 'lift',
      slots: [
        slot('push_1', ['inc_db_press'], 4, 6, 10),
        slot('push_2', ['flat_mach_press', 'flat_db_press'], 3, 8, 12),
        slot('push_3', ['seated_db_ohp'], 3, 6, 10),
        slot('push_4', ['cable_lat_raise'], 4, 12, 20),
        slot('push_5', ['rope_pushdown'], 3, 10, 15),
        slot('push_6', ['oh_cable_ext'], 2, 12, 15)
      ]
    },
    pull: {
      id: 'pull', name: 'Pull', kind: 'lift',
      slots: [
        slot('pull_1', ['pullup', 'assisted_pullup'], 4, 6, 10),
        slot('pull_2', ['cs_row'], 4, 8, 12),
        slot('pull_3', ['ng_pulldown'], 3, 8, 12),
        slot('pull_4', ['rear_delt_fly'], 4, 12, 20),
        slot('pull_5', ['inc_db_curl'], 3, 8, 12),
        slot('pull_6', ['hammer_curl'], 2, 10, 15)
      ]
    },
    legs: {
      id: 'legs', name: 'Legs & Abs', kind: 'lift',
      slots: [
        slot('legs_1', ['back_squat', 'hack_squat'], 4, 6, 10),
        slot('legs_2', ['rdl'], 3, 8, 12),
        slot('legs_3', ['bss'], 3, 8, 12, { perSide: true }),
        slot('legs_4', ['calf_raise'], 4, 10, 15),
        slot('legs_5', ['hlr'], 3, 8, 15),
        slot('legs_6', ['cable_crunch'], 3, 10, 15)
      ]
    },
    zone2: {
      id: 'zone2', name: 'Rest or Zone 2', kind: 'cardio_optional',
      cardio: { optional: true, minutesMin: 30, minutesMax: 40, cue: 'Conversational intensity. Incline walk, cycle, jog, swim, or other steady work.' },
      restIsValid: true
    },
    upper: {
      id: 'upper', name: 'Upper', kind: 'lift',
      slots: [
        slot('upper_1', ['inc_bb_press'], 4, 6, 10),
        slot('upper_2', ['pullup', 'lat_pulldown'], 4, 8, 12),
        slot('upper_3', ['sa_cable_row'], 3, 10, 12, { perSide: true }),
        slot('upper_4', ['db_lat_raise'], 4, 12, 20),
        slot('upper_5', ['cable_curl'], 3, 10, 15),
        slot('upper_6', ['tri_pushdown'], 3, 10, 15)
      ]
    },
    conditioning: {
      id: 'conditioning', name: 'Conditioning & Abs', kind: 'conditioning',
      cardio: {
        optional: false,
        choices: [
          { id: 'zone2', label: 'Zone 2, 30–45 min', minutesMin: 30, minutesMax: 45 },
          { id: 'intervals', label: 'Intervals: 10 × (30 s hard / 90 s easy)', rounds: 10, hardSec: 30, easySec: 90 }
        ]
      },
      circuit: { rounds: 3 },
      slots: [
        slot('cond_1', ['ab_wheel'], 3, 8, 12),
        slot('cond_2', ['reverse_crunch'], 3, 12, 20),
        slot('cond_3', ['side_plank'], 3, null, null, { perSide: true, timed: { secMin: 30, secMax: 45 } })
      ]
    }
  };

  const DEFAULT_SCHEDULE = { push: 'mon', pull: 'tue', legs: 'wed', zone2: 'thu', upper: 'fri', conditioning: 'sat' };

  const OR_SLOTS = [
    { slotId: 'push_2', label: 'Flat press (Push day)', options: ['flat_mach_press', 'flat_db_press'] },
    { slotId: 'pull_1', label: 'Vertical pull (Pull day)', options: ['pullup', 'assisted_pullup'] },
    { slotId: 'legs_1', label: 'Squat (Legs day)', options: ['back_squat', 'hack_squat'] },
    { slotId: 'upper_2', label: 'Vertical pull (Upper day)', options: ['pullup', 'lat_pulldown'] }
  ];

  const EQUIPMENT = [
    { id: 'barbell', label: 'Barbell + rack/bench' },
    { id: 'dumbbells', label: 'Dumbbells' },
    { id: 'cables', label: 'Cable stack' },
    { id: 'machines', label: 'Selectorized machines' },
    { id: 'pullup_bar', label: 'Pull-up bar' },
    { id: 'assisted_pullup', label: 'Assisted pull-up machine' },
    { id: 'hack_squat', label: 'Hack squat' },
    { id: 'ab_wheel', label: 'Ab wheel' },
    { id: 'bike_rower', label: 'Bike or rower' }
  ];

  const EFFORT_GUIDANCE = {
    short: 'Most working sets end 1–2 reps before failure. Taking the last isolation set to failure is optional. Never take heavy compounds to failure.',
    rir: 'RIR = reps in reserve: how many more clean reps you could have done when you stopped the set.',
    warmup: 'Warm-up sets are logged but excluded from completion and progression math.'
  };

  const REST_DEFAULTS = { compound: 150, isolation: 75 }; // seconds; configurable, not enforced

  CS.plan = { EXERCISES, EXERCISE_MAP, DEFAULT_TEMPLATES, DEFAULT_SCHEDULE, OR_SLOTS, EQUIPMENT, EFFORT_GUIDANCE, REST_DEFAULTS };
})();

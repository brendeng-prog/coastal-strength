/* Coastal Strength — core/util.js
   Plain-script module. Attaches to window.CS.util. No DOM access. */
(function () {
  const CS = (window.CS = window.CS || {});
  const U = {};

  U.uid = function (prefix) {
    return prefix + '_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 9);
  };

  U.defaultTz = function () {
    try { return Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC'; } catch (e) { return 'UTC'; }
  };

  const fmtCache = {};
  function fmtFor(tz) {
    if (fmtCache[tz]) return fmtCache[tz];
    let f;
    try {
      f = new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit' });
    } catch (e) {
      f = new Intl.DateTimeFormat('en-CA', { year: 'numeric', month: '2-digit', day: '2-digit' });
    }
    fmtCache[tz] = f;
    return f;
  }

  /* Local calendar date (YYYY-MM-DD) for an instant, in the given IANA zone.
     Schedules and daily logs key off this; timestamps stay UTC ISO. */
  U.localDate = function (ts, tz) {
    const d = ts instanceof Date ? ts : new Date(ts);
    const parts = fmtFor(tz || U.defaultTz()).formatToParts(d);
    const get = (t) => parts.find((p) => p.type === t).value;
    return get('year') + '-' + get('month') + '-' + get('day');
  };

  U.WEEKDAYS = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];
  U.WEEKDAY_LABEL = { mon: 'Monday', tue: 'Tuesday', wed: 'Wednesday', thu: 'Thursday', fri: 'Friday', sat: 'Saturday', sun: 'Sunday' };
  U.WEEKDAY_SHORT = { mon: 'Mon', tue: 'Tue', wed: 'Wed', thu: 'Thu', fri: 'Fri', sat: 'Sat', sun: 'Sun' };

  function split(localDate) {
    const p = localDate.split('-').map(Number);
    return { y: p[0], m: p[1], d: p[2] };
  }

  U.isLocalDate = function (s) {
    return typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s);
  };

  U.weekday = function (localDate) {
    const { y, m, d } = split(localDate);
    const dow = new Date(Date.UTC(y, m - 1, d)).getUTCDay(); // 0 = Sunday
    return U.WEEKDAYS[(dow + 6) % 7];
  };

  U.addDays = function (localDate, n) {
    const { y, m, d } = split(localDate);
    return new Date(Date.UTC(y, m - 1, d) + n * 86400000).toISOString().slice(0, 10);
  };

  U.diffDays = function (a, b) {
    const A = split(a), B = split(b);
    return Math.round((Date.UTC(B.y, B.m - 1, B.d) - Date.UTC(A.y, A.m - 1, A.d)) / 86400000);
  };

  /* Monday-start weeks. */
  U.weekStart = function (localDate) {
    return U.addDays(localDate, -U.WEEKDAYS.indexOf(U.weekday(localDate)));
  };

  U.weekDates = function (localDate) {
    const s = U.weekStart(localDate);
    return U.WEEKDAYS.map((key, i) => ({ key, date: U.addDays(s, i) }));
  };

  U.fmtLocalDate = function (localDate, opts) {
    const { y, m, d } = split(localDate);
    const dt = new Date(Date.UTC(y, m - 1, d));
    const o = Object.assign({ month: 'short', day: 'numeric', timeZone: 'UTC' }, opts || {});
    return new Intl.DateTimeFormat('en-US', o).format(dt);
  };

  /* Units */
  U.LB_PER_KG = 2.2046226218;
  U.toUnit = function (value, from, to) {
    if (value == null || from === to) return value;
    return from === 'lb' ? value / U.LB_PER_KG : value * U.LB_PER_KG;
  };
  U.fmtNum = function (n, maxDecimals) {
    if (n == null || isNaN(n)) return '—';
    const md = maxDecimals == null ? 2 : maxDecimals;
    const r = Math.round(n * Math.pow(10, md)) / Math.pow(10, md);
    return String(r);
  };
  U.fmtLoad = function (n) { return U.fmtNum(n, 2); };

  /* Parse a numeric input. Returns { value, error }.
     Empty -> null value with no error. Negative -> error. */
  U.parseNum = function (raw, opts) {
    opts = opts || {};
    if (raw == null) return { value: null };
    const s = String(raw).trim().replace(',', '.');
    if (s === '') return { value: null };
    if (!/^-?\d*(\.\d*)?$/.test(s) || s === '-' || s === '.') return { value: null, error: 'Enter a number.' };
    const v = Number(s);
    if (isNaN(v)) return { value: null, error: 'Enter a number.' };
    if (v < 0) return { value: null, error: "Can't be negative." };
    if (opts.integer && Math.round(v) !== v) return { value: null, error: 'Whole numbers only.' };
    if (opts.max != null && v > opts.max) return { value: null, error: 'Too large.' };
    return { value: v };
  };

  U.fmtDuration = function (ms) {
    if (ms == null || ms < 0) ms = 0;
    const s = Math.floor(ms / 1000);
    const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
    const pad = (n) => (n < 10 ? '0' + n : '' + n);
    return h > 0 ? h + ':' + pad(m) + ':' + pad(sec) : m + ':' + pad(sec);
  };

  U.fmtClock = function (sec) {
    sec = Math.max(0, Math.round(sec));
    const m = Math.floor(sec / 60), s = sec % 60;
    return m + ':' + (s < 10 ? '0' : '') + s;
  };

  U.clone = function (o) { return JSON.parse(JSON.stringify(o)); };

  U.mean = function (arr) { return arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : null; };

  CS.util = U;
})();

/* Coastal Strength — core/stats.js
   Derived numbers for Today. Everything here is computed from logged records only. */
(function () {
  const CS = (window.CS = window.CS || {});
  const U = CS.util, D = CS.db;
  const S = {};

  /* Week ring: completed scheduled lifting sessions / scheduled lifting sessions, Mon–Sun.
     Cardio and rest days are never in the denominator. A lift template counts once per
     week regardless of which day it was actually done on. */
  S.weekRing = function (db, localDate) {
    const plan = D.activePlan(db);
    const week = U.weekDates(localDate);
    const first = week[0].date, last = week[6].date;
    const scheduledLift = Object.keys(db.profile.schedule).filter((t) => db.profile.schedule[t] && plan.templates[t] && plan.templates[t].kind === 'lift');
    const completed = {};
    D.sessionList(db).forEach((s) => {
      if (s.status === 'completed' && s.kind === 'lift' && s.localDate >= first && s.localDate <= last) completed[s.templateId] = true;
    });
    const days = week.map((d) => {
      const t = D.templateForWeekday(db, d.key);
      const sessions = D.sessionsOn(db, d.date);
      const forTemplate = sessions.find((s) => s.templateId === t.id);
      return {
        key: d.key, date: d.date, templateId: t.id, templateName: t.name, kind: t.kind,
        status: forTemplate ? forTemplate.status : (sessions.length ? 'other' : 'none'),
        isToday: d.date === localDate, isPast: d.date < localDate,
        sessions
      };
    });
    return {
      completed: scheduledLift.filter((t) => completed[t]).length,
      scheduled: scheduledLift.length,
      days
    };
  };

  S.todayPlan = function (db, localDate) {
    const wd = U.weekday(localDate);
    const t = D.templateForWeekday(db, wd);
    return { weekday: wd, template: t, session: D.sessionFor(db, t.id, localDate) };
  };

  /* Weight card: latest observation + 7-day average when ≥3 observations fall in the last 7 days.
     Missing days stay missing — no zeros, no interpolation. */
  S.weightSummary = function (db, localDate) {
    const latest = D.latestMeasurement(db, 'weight');
    if (!latest) return null;
    const from = U.addDays(localDate, -6);
    const byDay = {};
    db.measurements.filter((m) => m.type === 'weight' && m.localDate >= from && m.localDate <= localDate)
      .sort((a, b) => (a.createdAt < b.createdAt ? -1 : 1))
      .forEach((m) => { byDay[m.localDate] = U.toUnit(m.value, m.unit, db.profile.units); }); // last entry per day wins
    const vals = Object.values(byDay);
    return {
      latest: { value: U.toUnit(latest.value, latest.unit, db.profile.units), unit: db.profile.units, localDate: latest.localDate },
      avg7: vals.length >= 3 ? U.mean(vals) : null,
      avg7Count: vals.length,
      avg7Definition: 'Mean of the last weigh-in on each day with an observation in the trailing 7 days (' + vals.length + ' of 7 days). Shown only with 3+ observations.'
    };
  };

  /* At most two observations, each derived from a specific log. Neutral wording. */
  S.observations = function (db, localDate) {
    const out = [];
    const sessions = D.sessionList(db).filter((s) => s.status === 'completed' && s.kind === 'lift');
    const last = sessions[sessions.length - 1];
    if (last) {
      for (const inst of last.exercises) {
        if (inst.skipped) continue;
        const sets = D.logicalSets(inst, { completedOnly: true, kind: 'working' });
        const p = inst.prescription;
        if (!p.repMax || sets.length < p.sets) continue;
        const top = sets.slice(0, p.sets).every((x) => x.reps != null && x.reps >= p.repMax);
        if (top) {
          const ex = D.exercise(db, inst.exerciseId);
          out.push({ text: 'You hit the top of the range on all ' + p.sets + ' ' + ex.name.toLowerCase() + ' sets on ' + U.fmtLocalDate(last.localDate) + '.', source: { sessionId: last.id, instanceId: inst.instanceId } });
          break;
        }
      }
    }
    const weights = db.measurements.filter((m) => m.type === 'weight');
    const distinctDays = {};
    weights.forEach((m) => { distinctDays[m.localDate] = true; });
    if (Object.keys(distinctDays).length < 3) out.push({ text: 'Not enough weight history for a trend yet (' + Object.keys(distinctDays).length + ' of the 3 days needed).', source: null });
    return out.slice(0, 2);
  };

  CS.stats = S;
})();

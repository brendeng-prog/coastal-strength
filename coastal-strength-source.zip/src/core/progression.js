/* Coastal Strength — core/progression.js
   Transparent double progression. Every result carries its exact reasons.
   Nothing here rewrites a workout; results are suggestions the user decides on. */
(function () {
  const CS = (window.CS = window.CS || {});
  const U = CS.util, D = CS.db;
  const PR = {};

  function loadLabel(ex) {
    return { per_dumbbell: 'per dumbbell', total_bar: 'total bar', machine_stack: 'on the stack', assistance: 'assistance', added: 'added', none: '' }[ex.loadConvention] || '';
  }

  /* evaluate({ exercise, instance, session, db }) ->
     { status, reasons[], currentLoad, suggestedLoad, increment, unit, rirFlag, rirNote, decline }
     status: increase | assist_decrease | bodyweight_top | timed_top | hold | none | not_evaluated */
  PR.evaluate = function (args) {
    const ex = args.exercise, inst = args.instance, s = args.session, db = args.db;
    const p = inst.prescription;
    const reasons = [];
    const unit = (inst.sets.find((x) => x.unit) || {}).unit || (db && db.profile.units) || 'lb';
    const inc = unit === 'kg' ? ex.incrementKg : ex.incrementLb;
    const base = { status: 'none', reasons, currentLoad: null, suggestedLoad: null, increment: inc, unit, rirFlag: false, rirNote: null, decline: null, exerciseName: ex.name };

    if (!s || s.status !== 'completed') {
      reasons.push('Session not finished. Increases are only evaluated for completed sessions.');
      return Object.assign(base, { status: 'not_evaluated' });
    }
    if (inst.skipped) {
      reasons.push('Exercise skipped this session.');
      return Object.assign(base, { status: 'not_evaluated' });
    }

    const done = D.logicalSets(inst, { completedOnly: true, kind: 'working' });
    reasons.push('Warm-up sets excluded. ' + done.length + ' of ' + p.sets + ' prescribed working sets completed.');
    if (done.length < p.sets) {
      reasons.push('Not every prescribed working set was completed, so no increase.');
      return base;
    }
    const evaluated = done.slice(0, p.sets);
    if (done.length > p.sets) reasons.push((done.length - p.sets) + ' extra set(s) logged; only the first ' + p.sets + ' prescribed sets are evaluated.');

    // RIR
    const rirLogged = evaluated.filter((x) => x.rir != null);
    const rirFlag = rirLogged.some((x) => x.rir <= 0);
    const rirNote = rirLogged.length ? null : 'RIR was not logged, so this used load and reps only.';
    base.rirFlag = rirFlag; base.rirNote = rirNote;

    // Timed holds
    if (ex.type === 'timed' && p.timed) {
      const top = evaluated.filter((x) => x.durationSec != null && x.durationSec >= p.timed.secMax).length;
      reasons.push(top + ' of ' + p.sets + ' holds reached ' + p.timed.secMax + ' s.');
      if (top < p.sets) { reasons.push('Progress toward ' + p.timed.secMax + ' s on every hold.'); return base; }
      reasons.push('Every hold reached the upper bound. Make the hold harder (e.g. feet elevated) or extend the target — your call.');
      return Object.assign(base, { status: 'timed_top' });
    }

    // Load consistency
    const loads = evaluated.map((x) => x.load);
    const usesLoad = ex.loadConvention !== 'none';
    if (usesLoad) {
      const distinct = {};
      loads.forEach((l) => { distinct[l == null ? 'none' : String(l)] = true; });
      const mixed = evaluated.some((x) => x.mixedLoad) || Object.keys(distinct).length > 1;
      if (mixed) {
        reasons.push('Sets used different loads (' + loads.map((l) => (l == null ? '—' : U.fmtLoad(l))).join(', ') + ' ' + unit + '). A blanket increase is never suggested for a mixed-load session.');
        return base;
      }
      if (loads[0] == null) {
        reasons.push('No load was logged, so no increase can be computed.');
        return base;
      }
    }
    const load = usesLoad ? loads[0] : null;
    base.currentLoad = load;

    // Rep test: every prescribed working set at or above the top of the range
    const top = evaluated.filter((x) => x.reps != null && x.reps >= p.repMax).length;
    reasons.push(top + ' of ' + p.sets + ' sets reached ' + p.repMax + ' reps' + (usesLoad ? ' at ' + U.fmtLoad(load) + ' ' + unit + ' ' + loadLabel(ex) : '') + ' (' + evaluated.map((x) => (x.reps == null ? '—' : x.reps)).join('/') + ').');
    if (top < p.sets) {
      reasons.push('An increase needs all ' + p.sets + ' sets at ' + p.repMax + '+ reps. Hold the load and build reps.');
      base.decline = PR.detectDecline(db, ex.id, s.id);
      return base;
    }

    let result;
    if (ex.type === 'bodyweight') {
      reasons.push('All sets at the top of the range. Prioritize control and clean reps first; when that is solid, ' + (ex.family === 'vertical_pull' ? 'switch to weighted pull-ups (a separate history).' : 'move to a harder variation.'));
      result = Object.assign(base, { status: 'bodyweight_top' });
    } else if (ex.type === 'assisted') {
      const next = Math.max(0, load - inc);
      if (load <= 0) reasons.push('Assistance is already 0. Try bodyweight pull-ups next time (a separate history).');
      else reasons.push('All sets at the top of the range. Less assistance is progress: try ' + U.fmtLoad(next) + ' ' + unit + ' assistance (' + U.fmtLoad(inc) + ' ' + unit + ' less).');
      result = Object.assign(base, { status: 'assist_decrease', suggestedLoad: load <= 0 ? null : next });
    } else {
      const next = load + inc;
      reasons.push('All sets at the top of the range. Smallest configured step for this exercise is ' + U.fmtLoad(inc) + ' ' + unit + ': try ' + U.fmtLoad(next) + ' ' + unit + ' ' + loadLabel(ex) + ' next session.');
      result = Object.assign(base, { status: 'increase', suggestedLoad: next });
    }
    if (rirFlag) reasons.push('One or more sets were logged at 0 RIR. Holding the load another session may be appropriate.');
    if (rirNote) reasons.push(rirNote);
    return result;
  };

  /* Repeated decline: three most recent completed sessions of this exercise, each with
     fewer total working reps than the one before at the same or lower load. Returns a
     neutral prompt string or null. Never diagnoses. */
  PR.detectDecline = function (db, exerciseId, throughSessionId) {
    if (!db) return null;
    const hist = PR.history(db, exerciseId).filter((h) => h.status === 'completed');
    const idx = hist.findIndex((h) => h.sessionId === throughSessionId);
    const upto = idx >= 0 ? hist.slice(0, idx + 1) : hist;
    if (upto.length < 4) return null;
    const last4 = upto.slice(-4);
    for (let i = 1; i < last4.length; i++) {
      const prev = last4[i - 1], cur = last4[i];
      if (prev.totalReps == null || cur.totalReps == null) return null;
      if (!(cur.totalReps < prev.totalReps && (cur.topLoad == null || prev.topLoad == null || cur.topLoad <= prev.topLoad))) return null;
    }
    return 'Working reps have dropped over the last three sessions of this exercise. Worth a look at sleep, recovery, technique, and recent workload.';
  };

  /* Per-exercise session history (chronological). One entry per session where the exercise appeared. */
  PR.history = function (db, exerciseId) {
    const out = [];
    D.sessionList(db).forEach((s) => {
      s.exercises.forEach((inst) => {
        if (inst.exerciseId !== exerciseId || inst.skipped) return;
        const sets = D.logicalSets(inst, { completedOnly: true, kind: 'working' });
        if (!sets.length && s.status !== 'completed') return;
        const loads = sets.filter((x) => x.load != null).map((x) => x.load);
        out.push({
          sessionId: s.id, localDate: s.localDate, status: s.status, templateName: s.templateName,
          prescription: inst.prescription, sets,
          totalReps: sets.length ? sets.reduce((a, x) => a + (x.reps || 0), 0) : null,
          topLoad: loads.length ? Math.max.apply(null, loads) : null
        });
      });
    });
    return out;
  };

  CS.progression = PR;
})();

/* Coastal Strength — core/db.js
   The data model and every mutation on it. Pure functions over a plain object.
   The UI never mutates the db directly; it calls these through the store. */
(function () {
  const CS = (window.CS = window.CS || {});
  const U = CS.util, P = CS.plan;
  const D = {};

  D.SCHEMA_VERSION = 1;

  /* ---------- creation ---------- */

  D.createInitial = function (input, nowIso) {
    nowIso = nowIso || new Date().toISOString();
    const tz = input.timezone || U.defaultTz();
    const planId = U.uid('plan');
    const db = {
      schemaVersion: D.SCHEMA_VERSION,
      createdAt: nowIso,
      profile: {
        name: input.name || '',
        heightIn: input.heightIn == null ? null : input.heightIn,
        units: input.units === 'kg' ? 'kg' : 'lb',
        timezone: tz,
        schedule: Object.assign({}, P.DEFAULT_SCHEDULE, input.schedule || {}),
        equipment: input.equipment || {},
        picks: Object.assign({}, input.picks || {}),
        nutritionMode: input.nutritionMode || 'undecided',
        calorieTarget: input.calorieTarget == null ? null : input.calorieTarget,
        experience: input.experience || '',
        limitations: input.limitations || '',
        frameNoteShown: !!input.frameNoteShown,
        onboarded: true
      },
      exercises: U.clone(P.EXERCISE_MAP),
      planVersions: [{ id: planId, version: 1, createdAt: nowIso, note: 'Default plan', templates: U.clone(P.DEFAULT_TEMPLATES) }],
      activePlanVersionId: planId,
      sessions: {},
      sessionOrder: [],
      measurements: [],
      cardioSessions: [],
      recoveryLogs: {},
      nutrition: { days: {}, savedFoods: [] },
      suggestions: {},
      timer: null,
      settings: {
        restDefaults: Object.assign({}, P.REST_DEFAULTS),
        autoStartRest: true,
        restSound: true,
        restVibrate: true,
        theme: 'auto'
      }
    };
    // Default picks: first option of every OR slot unless the user chose.
    P.OR_SLOTS.forEach((s) => { if (!db.profile.picks[s.slotId]) db.profile.picks[s.slotId] = s.options[0]; });
    if (input.weight != null) {
      D.addMeasurement(db, { type: 'weight', value: input.weight, unit: input.weightUnit || db.profile.units, localDate: input.weightDate || U.localDate(nowIso, tz) }, nowIso);
    }
    return db;
  };

  /* ---------- lookups ---------- */

  D.activePlan = function (db) {
    return db.planVersions.find((p) => p.id === db.activePlanVersionId) || db.planVersions[db.planVersions.length - 1];
  };

  D.templateForWeekday = function (db, weekday) {
    const plan = D.activePlan(db);
    const tid = Object.keys(db.profile.schedule).find((t) => db.profile.schedule[t] === weekday && plan.templates[t]);
    return tid ? plan.templates[tid] : { id: 'rest', name: 'Rest', kind: 'rest' };
  };

  D.exercise = function (db, id) { return db.exercises[id] || P.EXERCISE_MAP[id] || null; };

  D.sessionList = function (db) { return db.sessionOrder.map((id) => db.sessions[id]).filter(Boolean); };

  D.sessionsOn = function (db, localDate) { return D.sessionList(db).filter((s) => s.localDate === localDate); };

  D.findActiveSession = function (db) {
    return D.sessionList(db).find((s) => s.status === 'in_progress' || s.status === 'paused') || null;
  };

  D.sessionFor = function (db, templateId, localDate) {
    return D.sessionList(db).find((s) => s.templateId === templateId && s.localDate === localDate) || null;
  };

  /* Most recent session where this exercise had at least one completed working set.
     Returns { sessionId, localDate, sets:[logical sets], prescription } or null. */
  D.lastPerformance = function (db, exerciseId, excludeSessionId) {
    const list = D.sessionList(db);
    for (let i = list.length - 1; i >= 0; i--) {
      const s = list[i];
      if (s.id === excludeSessionId) continue;
      for (const inst of s.exercises || []) {
        if (inst.exerciseId !== exerciseId || inst.skipped) continue;
        const sets = D.logicalSets(inst, { completedOnly: true, kind: 'working' });
        if (sets.length) return { sessionId: s.id, localDate: s.localDate, sets, prescription: inst.prescription, sidesSeparate: !!inst.sidesSeparate };
      }
    }
    return null;
  };

  /* Pending progression decision for this exercise that has not yet been applied to a session. */
  D.pendingSuggestion = function (db, exerciseId) {
    const all = Object.values(db.suggestions).filter((s) => s.exerciseId === exerciseId && !s.consumedBy);
    all.sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
    return all[0] || null;
  };

  /* ---------- logical sets (unilateral pairs collapse to one) ---------- */

  D.logicalSets = function (inst, opts) {
    opts = opts || {};
    const kind = opts.kind || null;
    const sets = (inst.sets || []).filter((s) => !kind || s.kind === kind);
    const out = [];
    const seen = {};
    for (const s of sets) {
      if (s.side === 'both' || !s.pairId) {
        out.push({ setIds: [s.id], load: s.load, unit: s.unit, reps: s.reps, durationSec: s.durationSec, rir: s.rir, completed: !!s.completed, mixedLoad: false, kind: s.kind, sides: null, notes: s.notes });
      } else {
        if (seen[s.pairId]) continue;
        seen[s.pairId] = true;
        const pair = sets.filter((x) => x.pairId === s.pairId);
        const L = pair.find((x) => x.side === 'L') || null, R = pair.find((x) => x.side === 'R') || null;
        const both = [L, R].filter(Boolean);
        const loads = both.map((x) => x.load);
        const mixed = loads.length > 1 && !(loads[0] === loads[1]);
        const reps = both.every((x) => x.reps != null) ? Math.min.apply(null, both.map((x) => x.reps)) : null;
        const durs = both.filter((x) => x.durationSec != null).map((x) => x.durationSec);
        const rirs = both.filter((x) => x.rir != null).map((x) => x.rir);
        out.push({
          setIds: both.map((x) => x.id), load: mixed ? null : loads[0], unit: both[0].unit,
          reps: both.length === 2 ? reps : both[0].reps,
          durationSec: durs.length ? Math.min.apply(null, durs) : null,
          rir: rirs.length ? Math.min.apply(null, rirs) : null,
          completed: both.length === 2 && both.every((x) => x.completed), mixedLoad: mixed, kind: s.kind,
          sides: { L: L, R: R }, notes: both.map((x) => x.notes).filter(Boolean).join(' / ')
        });
      }
    }
    return opts.completedOnly ? out.filter((s) => s.completed) : out;
  };

  /* ---------- session creation ---------- */

  function newSet(exercise, unit, base, kind) {
    return {
      id: U.uid('set'), kind: kind || 'working', side: 'both', pairId: null,
      load: base && base.load != null ? base.load : null,
      unit: unit,
      reps: base && base.reps != null ? base.reps : null,
      durationSec: base && base.durationSec != null ? base.durationSec : null,
      rir: null, completed: false, completedAt: null,
      prefilled: !!(base && (base.load != null || base.reps != null || base.durationSec != null)),
      notes: ''
    };
  }

  function convertLoad(load, from, to) {
    if (load == null || from === to) return load;
    return Math.round(U.toUnit(load, from, to) * 2) / 2;
  }

  /* Prefill from the most recent comparable performance. Never marks anything completed. */
  D.buildSets = function (db, exercise, prescription, excludeSessionId) {
    const unit = db.profile.units;
    const last = D.lastPerformance(db, exercise.id, excludeSessionId);
    const sugg = D.pendingSuggestion(db, exercise.id);
    const sets = [];
    for (let i = 0; i < prescription.sets; i++) {
      let base = null;
      if (last) {
        const src = last.sets[i] || last.sets[last.sets.length - 1];
        base = { load: convertLoad(src.load, src.unit, unit), reps: src.reps, durationSec: src.durationSec };
        if (sugg && sugg.decision && sugg.decision !== 'dismissed' && sugg.appliedLoad != null) {
          base.load = convertLoad(sugg.appliedLoad, sugg.unit, unit);
        }
      }
      sets.push(newSet(exercise, unit, base, 'working'));
    }
    return { sets, last, suggestion: sugg };
  };

  D.createSession = function (db, templateId, localDate, nowIso) {
    const plan = D.activePlan(db);
    const t = plan.templates[templateId];
    if (!t) throw new Error('Unknown template ' + templateId);
    const id = U.uid('sess');
    const session = {
      id, templateId, templateName: t.name, kind: t.kind, planVersionId: plan.id,
      localDate, weekday: U.weekday(localDate), scheduledWeekday: db.profile.schedule[templateId] || null,
      status: 'planned', createdAt: nowIso, startedAt: null, finishedAt: null, segments: [],
      exercises: [], notes: '', energy: null, difficulty: null, soreness: null, cardio: null
    };
    (t.slots || []).forEach((slot, i) => {
      const exId = db.profile.picks[slot.slotId] && slot.options.indexOf(db.profile.picks[slot.slotId]) >= 0 ? db.profile.picks[slot.slotId] : slot.options[0];
      const ex = D.exercise(db, exId);
      const prescription = { sets: slot.sets, repMin: slot.repMin, repMax: slot.repMax, perSide: !!slot.perSide, timed: slot.timed ? U.clone(slot.timed) : null };
      const built = D.buildSets(db, ex, prescription, id);
      session.exercises.push({
        instanceId: U.uid('inst'), slotId: slot.slotId, exerciseId: exId, order: i,
        prescription, sets: built.sets, skipped: false, skipReason: '', substitutedFrom: null, notes: '',
        restSec: ex.compound ? db.settings.restDefaults.compound : db.settings.restDefaults.isolation,
        sidesSeparate: false,
        lastPerformance: built.last ? { sessionId: built.last.sessionId, localDate: built.last.localDate, sets: built.last.sets.map((s) => ({ load: s.load, unit: s.unit, reps: s.reps, durationSec: s.durationSec })) } : null,
        suggestionKey: built.suggestion ? built.suggestion.key : null
      });
      if (built.suggestion) built.suggestion.consumedBy = id;
    });
    db.sessions[id] = session;
    db.sessionOrder.push(id);
    return id;
  };

  /* Start (or resume) the session for a template on a date. Idempotent: one session per template per date. */
  D.startSession = function (db, templateId, localDate, nowIso) {
    let s = D.sessionFor(db, templateId, localDate);
    if (s && s.status === 'completed') return s.id; // don't restart a finished session
    if (!s) s = db.sessions[D.createSession(db, templateId, localDate, nowIso)];
    if (s.status === 'planned' || s.status === 'skipped') {
      s.status = 'in_progress';
      s.startedAt = s.startedAt || nowIso;
      s.segments.push({ start: nowIso, end: null });
    } else if (s.status === 'paused') {
      D.resumeSession(db, s.id, nowIso);
    }
    return s.id;
  };

  D.pauseSession = function (db, sid, nowIso) {
    const s = db.sessions[sid];
    if (!s || s.status !== 'in_progress') return;
    const open = s.segments.find((g) => !g.end);
    if (open) open.end = nowIso;
    s.status = 'paused';
  };

  D.resumeSession = function (db, sid, nowIso) {
    const s = db.sessions[sid];
    if (!s || s.status !== 'paused') return;
    s.segments.push({ start: nowIso, end: null });
    s.status = 'in_progress';
  };

  /* Active time from timestamps only. */
  D.activeMs = function (s, nowMs) {
    let total = 0;
    (s.segments || []).forEach((g) => {
      const a = Date.parse(g.start), b = g.end ? Date.parse(g.end) : nowMs;
      if (!isNaN(a) && !isNaN(b) && b > a) total += b - a;
    });
    return total;
  };

  D.finishSession = function (db, sid, nowIso) {
    const s = db.sessions[sid];
    if (!s || s.status === 'completed') return s;
    const open = s.segments.find((g) => !g.end);
    if (open) open.end = nowIso;
    s.status = 'completed';
    s.finishedAt = nowIso;
    if (db.timer && db.timer.sessionId === sid) db.timer = null;
    // Progression suggestions are built once, at completion, from what was actually logged.
    if (CS.progression) {
      s.exercises.forEach((inst) => {
        const ex = D.exercise(db, inst.exerciseId);
        const result = CS.progression.evaluate({ exercise: ex, instance: inst, session: s, db });
        const key = sid + ':' + inst.instanceId;
        db.suggestions[key] = {
          key, sessionId: sid, instanceId: inst.instanceId, exerciseId: inst.exerciseId, createdAt: nowIso,
          result, decision: null, appliedLoad: null, unit: result.unit || db.profile.units, consumedBy: null
        };
      });
    }
    return s;
  };

  D.decideSuggestion = function (db, key, decision, overrideLoad) {
    const sg = db.suggestions[key];
    if (!sg) return;
    sg.decision = decision;
    sg.decidedAt = new Date().toISOString();
    if (decision === 'accepted') sg.appliedLoad = sg.result.suggestedLoad;
    else if (decision === 'overridden') sg.appliedLoad = overrideLoad;
    else sg.appliedLoad = null;
  };

  D.skipSession = function (db, templateId, localDate, nowIso, reason) {
    let s = D.sessionFor(db, templateId, localDate);
    if (!s) s = db.sessions[D.createSession(db, templateId, localDate, nowIso)];
    if (s.status === 'completed') return s.id;
    s.status = 'skipped';
    s.skipReason = reason || '';
    return s.id;
  };

  /* ---------- set-level mutations ---------- */

  function findInst(db, sid, iid) {
    const s = db.sessions[sid];
    return s ? s.exercises.find((e) => e.instanceId === iid) : null;
  }
  D.instance = findInst;

  D.setField = function (db, sid, iid, setId, field, value) {
    const inst = findInst(db, sid, iid);
    if (!inst) return;
    const set = inst.sets.find((x) => x.id === setId);
    if (!set) return;
    if (['load', 'reps', 'durationSec', 'rir', 'notes'].indexOf(field) < 0) return;
    set[field] = value;
    if (field !== 'notes') set.prefilled = false;
    // Linked unilateral: nothing to mirror (single row). Separate rows are edited individually.
  };

  D.toggleComplete = function (db, sid, iid, setId, nowIso) {
    const inst = findInst(db, sid, iid);
    if (!inst) return;
    const set = inst.sets.find((x) => x.id === setId);
    if (!set) return;
    if (set.completed) {
      set.completed = false;
      set.completedAt = null;
    } else {
      set.completed = true;
      set.completedAt = nowIso;
      set.prefilled = false;
    }
    return set.completed;
  };

  D.addSet = function (db, sid, iid, kind) {
    const inst = findInst(db, sid, iid);
    if (!inst) return;
    const ex = D.exercise(db, inst.exerciseId);
    const unit = db.profile.units;
    const lastWorking = inst.sets.slice().reverse().find((s) => s.kind === 'working');
    const base = lastWorking ? { load: lastWorking.load, reps: lastWorking.reps, durationSec: lastWorking.durationSec } : null;
    if (inst.sidesSeparate) {
      const pairId = U.uid('pair');
      const a = newSet(ex, unit, base, kind); a.side = 'L'; a.pairId = pairId;
      const b = newSet(ex, unit, base, kind); b.side = 'R'; b.pairId = pairId;
      a.prefilled = b.prefilled = false;
      inst.sets.push(a, b);
      return a.id;
    }
    const s = newSet(ex, unit, base, kind);
    s.prefilled = false;
    if (kind === 'warmup') {
      const firstWorking = inst.sets.findIndex((x) => x.kind === 'working');
      inst.sets.splice(firstWorking < 0 ? inst.sets.length : firstWorking, 0, s);
    } else inst.sets.push(s);
    return s.id;
  };

  D.deleteSet = function (db, sid, iid, setId) {
    const inst = findInst(db, sid, iid);
    if (!inst) return;
    const set = inst.sets.find((x) => x.id === setId);
    if (!set) return;
    inst.sets = inst.sets.filter((x) => (set.pairId ? x.pairId !== set.pairId : x.id !== setId));
  };

  D.setKind = function (db, sid, iid, setId, kind) {
    const inst = findInst(db, sid, iid);
    if (!inst) return;
    const set = inst.sets.find((x) => x.id === setId);
    if (!set) return;
    const targets = set.pairId ? inst.sets.filter((x) => x.pairId === set.pairId) : [set];
    targets.forEach((t) => { t.kind = kind; });
  };

  /* Switch a unilateral exercise between linked (one row = both sides) and separate L/R rows. */
  D.setSidesSeparate = function (db, sid, iid, separate) {
    const inst = findInst(db, sid, iid);
    if (!inst || !!inst.sidesSeparate === !!separate) return;
    const next = [];
    if (separate) {
      inst.sets.forEach((s) => {
        if (s.side !== 'both') { next.push(s); return; }
        const pairId = U.uid('pair');
        const L = Object.assign({}, s, { id: U.uid('set'), side: 'L', pairId });
        const R = Object.assign({}, s, { id: U.uid('set'), side: 'R', pairId });
        next.push(L, R);
      });
    } else {
      const seen = {};
      inst.sets.forEach((s) => {
        if (s.side === 'both' || !s.pairId) { next.push(s); return; }
        if (seen[s.pairId]) return;
        seen[s.pairId] = true;
        const pair = inst.sets.filter((x) => x.pairId === s.pairId);
        const both = pair.every((x) => x.completed);
        const merged = Object.assign({}, pair[0], { id: U.uid('set'), side: 'both', pairId: null, completed: both, completedAt: both ? pair[0].completedAt : null });
        if (pair.length === 2 && pair[0].reps != null && pair[1].reps != null) merged.reps = Math.min(pair[0].reps, pair[1].reps);
        next.push(merged);
      });
    }
    inst.sets = next;
    inst.sidesSeparate = !!separate;
  };

  D.skipExercise = function (db, sid, iid, reason) {
    const inst = findInst(db, sid, iid);
    if (!inst) return;
    inst.skipped = true;
    inst.skipReason = reason || '';
  };

  D.unskipExercise = function (db, sid, iid) {
    const inst = findInst(db, sid, iid);
    if (!inst) return;
    inst.skipped = false;
    inst.skipReason = '';
  };

  /* Substitution keeps separate histories: the new exercise prefills from ITS own history. */
  D.substituteExercise = function (db, sid, iid, newExerciseId) {
    const inst = findInst(db, sid, iid);
    const ex = D.exercise(db, newExerciseId);
    if (!inst || !ex) return;
    const anyDone = inst.sets.some((s) => s.completed);
    if (anyDone) return false; // never rewrite logged work
    inst.substitutedFrom = inst.substitutedFrom || inst.exerciseId;
    inst.exerciseId = newExerciseId;
    const built = D.buildSets(db, ex, inst.prescription, sid);
    inst.sets = built.sets;
    inst.sidesSeparate = false;
    inst.lastPerformance = built.last ? { sessionId: built.last.sessionId, localDate: built.last.localDate, sets: built.last.sets.map((s) => ({ load: s.load, unit: s.unit, reps: s.reps, durationSec: s.durationSec })) } : null;
    inst.restSec = ex.compound ? db.settings.restDefaults.compound : db.settings.restDefaults.isolation;
    if (built.suggestion) built.suggestion.consumedBy = sid;
    return true;
  };

  D.moveExercise = function (db, sid, iid, dir) {
    const s = db.sessions[sid];
    if (!s) return;
    const i = s.exercises.findIndex((e) => e.instanceId === iid);
    const j = i + dir;
    if (i < 0 || j < 0 || j >= s.exercises.length) return;
    const tmp = s.exercises[i]; s.exercises[i] = s.exercises[j]; s.exercises[j] = tmp;
    s.exercises.forEach((e, k) => { e.order = k; });
  };

  D.setInstanceField = function (db, sid, iid, field, value) {
    const inst = findInst(db, sid, iid);
    if (!inst) return;
    if (['notes', 'restSec'].indexOf(field) < 0) return;
    inst[field] = value;
  };

  D.setSessionField = function (db, sid, field, value) {
    const s = db.sessions[sid];
    if (!s) return;
    if (['notes', 'energy', 'difficulty', 'soreness'].indexOf(field) < 0) return;
    s[field] = value;
  };

  /* ---------- counts (completed only — prefilled never counts) ---------- */

  D.counts = function (session) {
    let workingDone = 0, workingPrescribed = 0, exercisesDone = 0, exercisesTotal = 0, warmupsDone = 0;
    (session.exercises || []).forEach((inst) => {
      if (inst.skipped) return;
      exercisesTotal++;
      const done = D.logicalSets(inst, { completedOnly: true, kind: 'working' }).length;
      workingDone += done;
      workingPrescribed += inst.prescription.sets;
      warmupsDone += D.logicalSets(inst, { completedOnly: true, kind: 'warmup' }).length;
      if (done >= inst.prescription.sets) exercisesDone++;
    });
    return { workingDone, workingPrescribed, exercisesDone, exercisesTotal, warmupsDone };
  };

  /* ---------- measurements ---------- */

  D.addMeasurement = function (db, m, nowIso) {
    const rec = { id: U.uid('meas'), type: m.type, value: m.value, unit: m.unit || null, localDate: m.localDate, createdAt: nowIso || new Date().toISOString(), note: m.note || '' };
    db.measurements.push(rec);
    return rec.id;
  };

  D.latestMeasurement = function (db, type) {
    const list = db.measurements.filter((m) => m.type === type).sort((a, b) => (a.localDate < b.localDate ? 1 : a.localDate > b.localDate ? -1 : (a.createdAt < b.createdAt ? 1 : -1)));
    return list[0] || null;
  };

  /* ---------- rest timer (timestamp based; persisted so it survives navigation and reload) ---------- */

  D.startRest = function (db, seconds, nowMs, sessionId) {
    db.timer = { kind: 'rest', startedAt: nowMs, endsAt: nowMs + seconds * 1000, durationSec: seconds, pausedAt: null, remainingMs: null, alerted: false, sessionId: sessionId || null };
  };
  D.adjustRest = function (db, deltaSec, nowMs) {
    const t = db.timer; if (!t) return;
    if (t.pausedAt != null) t.remainingMs = Math.max(0, t.remainingMs + deltaSec * 1000);
    else t.endsAt = Math.max(nowMs, t.endsAt + deltaSec * 1000);
    t.alerted = false;
  };
  D.pauseRest = function (db, nowMs) {
    const t = db.timer; if (!t || t.pausedAt != null) return;
    t.pausedAt = nowMs; t.remainingMs = Math.max(0, t.endsAt - nowMs);
  };
  D.resumeRest = function (db, nowMs) {
    const t = db.timer; if (!t || t.pausedAt == null) return;
    t.endsAt = nowMs + t.remainingMs; t.pausedAt = null; t.remainingMs = null;
  };
  D.dismissRest = function (db) { db.timer = null; };
  D.restState = function (db, nowMs) {
    const t = db.timer; if (!t) return null;
    const remainingMs = t.pausedAt != null ? t.remainingMs : t.endsAt - nowMs;
    return { remainingSec: Math.max(0, Math.ceil(remainingMs / 1000)), done: remainingMs <= 0, paused: t.pausedAt != null, durationSec: t.durationSec, alerted: t.alerted };
  };

  /* ---------- migrations ---------- */

  D.migrate = function (db) {
    if (!db || typeof db !== 'object') return null;
    if (!db.schemaVersion) db.schemaVersion = 1;
    // Future schema bumps go here, one step at a time.
    return db;
  };

  CS.db = D;
})();
